/*
*This software program and documentation are copyrighted by The Hong Kong Polytechnic University. 
*The software program and documentation are supplied ��as *is��, without any accompanying services 
*from The University. The University does not warrant that the operation of the program will be 
*uninterrupted or error-free.The end-user understands that the program was developed for research 
*purposes and is advised not to rely exclusively on the program for any reason.
*
*IN NO EVENT SHALL THE HONG KONG POLYTECHNIC UNIVERSITY BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT, SPECIAL, 
*INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS 
*DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN AD- VISED OF THE POSSIBILITY OF SUCH DAMAGE. THE HONG 
*KONG POLYTECHNIC UNIVERSITY SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
*WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED HEREUNDER IS ON AN ��AS IS�� 
*BASIS, AND THE HONG KONG POLYTECHNIC UNIVERSITY HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, 
*ENHANCEMENTS, OR MODIFICATIONS.
*/
//=============================================================================
//
// File Name    : md5c.h
// Description  : MD5 message-digest algorithm
// Release Date : 16/07/13
// Author       : RSA Data Security, Inc. ,Xu Siyuan
// Modified     : PolyU
//
// Revision History
//---------------------------------------------------------------------------
// Date       Version      Author       Description
//---------------------------------------------------------------------------
// 1991       1.0          RSA Data Security, Inc
//16/07/13    1.1           PolyU        Converted into Synthesizable SystemC
//==========================================================================


#ifndef MD5C_H_
#define MD5C_H_

#include "define.h"


SC_MODULE( md5c ) {

  // Inputs
  sc_in_clk              clk;
  sc_in< bool >          rst;
/*
  sc_in< bool >          i_req;
  sc_in< bool >          i_final;
  sc_in< sc_uint<32> >   i_inputLen;

  // Outputs
  sc_out< bool >         o_busy;
  sc_out< bool >         o_start;
  sc_out< sc_uint<8> >   o_digest;
*/
   //inputs
  sc_in <sc_uint <32> > UUT_in;
  sc_in <bool > input_valid_signal;
  sc_in <bool > output_control_signal;
  //outputs
  sc_out<sc_uint<8> > UUT_out;
  sc_out  <bool > output_valid_signal;

  // Member variables declaration
  sc_uint<32>		m_inputLen;
  sc_uint<8>		m_input[ MD5C_INPUT_BUFSIZE ];

  sc_uint<32>	m_state[4];	/* state (ABCD) */
  sc_uint<32>	m_count[2];	/* number of bits, modulo 2^64 (lsb first) */
  sc_uint<8>	m_buffer[64];	/* input buffer */


  /* E */
  void entry();


  /* M */
  void MD5Init();
  void MD5Update();
  void MD5Final();
  void MD5Pad();
  void MD5Transform();



  SC_CTOR( md5c ){
      SC_CTHREAD( entry, clk.pos() );
      reset_signal_is(rst,false);
    }

  ~md5c(){};


};

#endif // MD5C_H_

