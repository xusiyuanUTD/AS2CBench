/*
*This software program and documentation are copyrighted by The Hong Kong Polytechnic University. 
*The software program and documentation are supplied ��as *is��, without any accompanying services 
*from The University. The University does not warrant that the operation of the program will be 
*uninterrupted or error-free.The end-user understands that the program was developed for research 
*purposes and is advised not to rely exclusively on the program for any reason.
*
*IN NO EVENT SHALL THE HONG KONG POLYTECHNIC UNIVERSITY BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT, SPECIAL, 
*INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS 
*DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN AD- VISED OF THE POSSIBILITY OF SUCH DAMAGE. THE HONG 
*KONG POLYTECHNIC UNIVERSITY SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
*WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED HEREUNDER IS ON AN ��AS IS�� 
*BASIS, AND THE HONG KONG POLYTECHNIC UNIVERSITY HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, 
*ENHANCEMENTS, OR MODIFICATIONS.
*/
//========================================================================================
// 
// File Name    : UUT.c
// Author       : PolyU DARC Lab
//                Benjamin Carrion Schafer, Xu Siyuan
// 
//          
//=======================================================================================

#include "define.h"
#include <stdio.h>
#include <unistd.h>
#include "hwlib.h"
#include "socal/socal.h"
#include "socal/hps.h"
#include "socal/alt_gpio.h"
#include <malloc.h>
#include "stdlib.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <sys/mman.h>
#include "hps_0.h"
#include <stdbool.h>

#define HW_REGS_BASE ( ALT_STM_OFST )
#define HW_REGS_SPAN ( 0x04000000 )
#define HW_REGS_MASK ( HW_REGS_SPAN - 1 )

 volatile unsigned long *h2p_lw_UUT_addr;
 volatile unsigned long *h2p_lw_outvalid_addr;

  //For data feeding
  FILE * in_file, *in_file_key,  *out_golden_file, *out_file;
  FILE  *out_aes_cipher_file, *diff_file;

  unsigned int  input_key[SIZE];
  unsigned int mode =1;



/*
** Compare results function
*/
void compare_results(){

  unsigned int outaes, out_golden, line=1, element=1, errors=0;

  // Close file where outputs are stored
  fclose(out_file);

  //  out_filter_file_read.open(OUTFILENAME);
  if (mode == 0) {
  out_file = fopen (OUTFILENAME, "rt");
  }
  else {
  out_file = fopen (OUTFILENAME_D, "rt");
  }

  if(!out_file){
	if (mode == 0) 
   printf(" Could not open  OUTFILENAME \n ");
	else
	printf("Could not open  OUTFILENAME_D \n" );
    exit(-1);
  }

    //
    //Load the golden pattern
    //

  if (mode == 0) {
  out_golden_file = fopen (OUTFILENAME_GOLDEN, "rt");
  }
  else {
  out_golden_file = fopen (OUTFILENAME_GOLDEN_D, "rt");
  }
  if(!out_golden_file){
	if (mode == 0)
    printf("Could not open  OUTFILENAME_GOLDEN \n" );
	else
    printf("Could not open  OUTFILENAME_GOLDEN_D \n" );
   exit(-1);
  }

    //
    //Dump the comparison result
    //
    diff_file = fopen (DIFFFILENAME, "w");
    if(!diff_file){
	 printf(" Could not open  DIFFFILENAME \n" );
	 
       }

    while(fscanf(out_golden_file, "%x", &out_golden) != EOF){
      fscanf(out_file,"%x", &outaes);
     
      if(outaes != out_golden){
	fprintf(diff_file,"\nOutput missmatch[line:%d][%d] Golden: %u -- Output: %u",line,element, out_golden, outaes);
	  errors++;
      }

      if(element == SIZE){
	element =0;
	line ++;
      }
      element ++;

   }

   if(errors == 0)
     printf("Finished simulation SUCCESSFULLY \n" );
    else
    printf("MISSMATCHES between Golden and Simulation \n" );



    fclose(out_file);
    fclose(diff_file);
    fclose(out_golden_file);


}



/*
** Send data thread
*/
void send(){

  // Variables declaration
  int i=0, ret=0,read,j=0;
  unsigned int  in_read, in_read_key;
  // Variables declaration
  unsigned int out_write[SIZE];
  
  if (mode == 0) {
    out_file = fopen (OUTFILENAME, "wt");
  }
  else {
    out_file = fopen (OUTFILENAME_D, "wt");
  }

  if(!out_file){
	if (mode == 0)
    printf("Could not open  OUTFILENAME \n" );
	else
    printf( "Could not open  OUTFILENAME_D \n" );
    exit(-1);
  }

  //Reset routine
  if (mode == 0) {
    in_file = fopen(INFILENAME, "rt");
  }
  else {
    in_file = fopen(INFILENAME_D, "rt");
  }

  if(!in_file){
   printf("Could not open  INFILENAME \n" );
    exit (-1);
  }

  in_file_key = fopen(INFILENAME_KEY, "rt");

  if(!in_file_key){
    printf( "Could not open INFILENAME_KEY \n" );
    exit (-1);
  }


  for(i=0; i < SIZE; i ++){
    fscanf(in_file_key, "%x", &in_read_key);
    alt_write_word(h2p_lw_UUT_addr, in_read_key);
  }

  j=0;


    while(fscanf(in_file,"%x", &in_read) != EOF){
	alt_write_word(h2p_lw_UUT_addr, in_read);
	//printf("in_read is %x\n",in_read);
       	j++;	
	//printf("j is %d\n",j);

	if(j==SIZE){

	  j=0;

	while(1)	{
  	 		 read=alt_read_word(h2p_lw_outvalid_addr);
		
			if(read==1)
			{
			for(i=0; i< SIZE; i++){
			 alt_write_word(h2p_lw_outvalid_addr,true);
   			 out_write[i]= alt_read_word(h2p_lw_UUT_addr);
			 fprintf(out_file,"%x ",(unsigned int)out_write[i]);
			}
			fprintf(out_file,"\n");    
			 break;
		
			}
	
			}
		}
	     					}
  
  
  
    fclose(in_file);
    fclose(in_file_key);

    printf( "Starting comparing results \n" );
   
   compare_results(); 



}

//--------------------------
// Main function
//--------------------------


int main(int argc, char **argv)
{


	void *virtual_base;
	int fd;
		double elapsed;
   
	// map the address space for the LED registers into user space so we can interact with them.
	// we'll actually map in the entire CSR span of the HPS since we want to access various registers within that span
	if( ( fd = open( "/dev/mem", ( O_RDWR | O_SYNC ) ) ) == -1 ) {
		printf( "ERROR: could not open \"/dev/mem\"...\n" );
		return( 1 );
	}
	virtual_base = mmap( NULL, HW_REGS_SPAN, ( PROT_READ | PROT_WRITE ), MAP_SHARED, fd, HW_REGS_BASE );	
	if( virtual_base == MAP_FAILED ) {
		printf( "ERROR: mmap() failed...\n" );
		close( fd );
		return(1);
	}
	h2p_lw_UUT_addr=virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + UUT_IO_BASE) & ( unsigned long)( HW_REGS_MASK ) );
	h2p_lw_outvalid_addr=virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + OUTPUT_VALID_BASE ) & ( unsigned long)( HW_REGS_MASK ) );
	

  	time_t end,start=time(NULL);
		send();
  	end = time(NULL);
    	elapsed = difftime(end, start);
  	printf("\n\nRunning time %10.4f\n", elapsed);

	if( munmap( virtual_base, HW_REGS_SPAN ) != 0 ) {
		printf( "ERROR: munmap() failed...\n" );
		close( fd );
		return( 1 );

	}
	close( fd );
	return 0;
}
