/*
*This software program and documentation are copyrighted by The Hong Kong Polytechnic University. 
*The software program and documentation are supplied ��as *is��, without any accompanying services 
*from The University. The University does not warrant that the operation of the program will be 
*uninterrupted or error-free.The end-user understands that the program was developed for research 
*purposes and is advised not to rely exclusively on the program for any reason.
*
*IN NO EVENT SHALL THE HONG KONG POLYTECHNIC UNIVERSITY BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT, SPECIAL, 
*INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS 
*DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN AD- VISED OF THE POSSIBILITY OF SUCH DAMAGE. THE HONG 
*KONG POLYTECHNIC UNIVERSITY SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
*WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED HEREUNDER IS ON AN ��AS IS�� 
*BASIS, AND THE HONG KONG POLYTECHNIC UNIVERSITY HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, 
*ENHANCEMENTS, OR MODIFICATIONS.
*/
//========================================================================================
// 
//
// File Name    : define.h
// Description  : Main definition header file for AES
// Release Date : 24/11/2014
// Author       : PolyU DARC Lab
//                Benjamin Carrion Schafer, Shuangnan Liu ,Xu Siyuan
//
// Revision History
//---------------------------------------------------------------------------------------
// Date        Version  Author       Description
//----------------------------------------------------------------------------------------
//24/11/2014     1.0     PolyU        definition file for AES
//=======================================================================================

#ifndef DEFINE_H
#define DEFINE_H

#include "systemc.h"

//#include <iostream>
#include "stdio.h"


#define SIZE 16

#define NB 4
#define NBb 16
#define nk 4                            
#define nr 10   
//#define MODE_ 0

#define INFILENAME                "aes_cipher_input.txt"
#define INFILENAME_D              "aes_decipher_input.txt"
#define INFILENAME_KEY            "aes_cipher_key.txt"

#define OUTFILENAME_GOLDEN        "aes_cipher_output_golden.txt"
#define OUTFILENAME               "aes_cipher_output.txt"
#define OUTFILENAME_GOLDEN_D      "aes_decipher_output_golden.txt"
#define OUTFILENAME_D             "aes_decipher_output.txt"
#define DIFFFILENAME              "diff.txt"

//#define WAVE_DUMP          // set do dump waveform or set as compile option -DWAVE_DUMP

#endif  // DEFINE_H

