/*
*This software program and documentation are copyrighted by The Hong Kong Polytechnic University. 
*The software program and documentation are supplied ��as *is��, without any accompanying services 
*from The University. The University does not warrant that the operation of the program will be 
*uninterrupted or error-free.The end-user understands that the program was developed for research 
*purposes and is advised not to rely exclusively on the program for any reason.
*
*IN NO EVENT SHALL THE HONG KONG POLYTECHNIC UNIVERSITY BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT, SPECIAL, 
*INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS 
*DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN AD- VISED OF THE POSSIBILITY OF SUCH DAMAGE. THE HONG 
*KONG POLYTECHNIC UNIVERSITY SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
*WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED HEREUNDER IS ON AN ��AS IS�� 
*BASIS, AND THE HONG KONG POLYTECHNIC UNIVERSITY HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, 
*ENHANCEMENTS, OR MODIFICATIONS.
*/
//============================================================================
//
//
// File Name    : aes.h
// Description  : ADVANCED ENCRYPTION STANDARD (AES) 128-bit
// Release Date : 16/07/13
// Author       : AES Versoin 1.4 pjc.co.jp. AES Versoin 1.4 pjc.co.jp
// Modified     : PolyU, Xu Siyuan
//
// Revision History
//---------------------------------------------------------------------------
// Date     Author      Version     Description
//---------------------------------------------------------------------------
// 2009    PJC.CO.JP    1.0         Original ANSI C description
//16/07/13  PolyU       1.1         Converted into Synthesizable SystemC
//===========================================================================
#ifndef AES_H
#define AES_H

#include "define.h"

 

SC_MODULE (aes) {
  // input
  sc_in<bool>          clk;
  sc_in<bool>          rst;
  sc_in<bool>          mode;

  //sc_in<sc_uint<8> >   idata[SIZE];
//  sc_in<sc_uint<8> >   ikey[SIZE];
  
 // sc_out<sc_uint<8> >  odata[SIZE];

   //inputs
  sc_in <sc_uint <8> > UUT_in;
  sc_in <bool > input_valid_signal;
  sc_in <bool > output_control_signal;
  //outputs
  sc_out<sc_uint<8> > UUT_out;
  sc_out  <bool > output_valid_signal;



  int w[60];                         
  int data[NB];

  sc_uint<8> keys[SIZE];
  sc_uint<8> init[SIZE];


  /* A */
  void AddRoundKey(int *,int);     

  /* C */
  int Computing(int *, int*);  

  /* D */
  int dataget(int *,int);

  /* K */
  void KeyExpansion(sc_uint<8> *, const  int*);     

  /* M */
  void MixColumns(int *);
  int mul(int,int);

  /* S */
  void ShiftRows(int *);   
  void SubBytes(int *, const int*);         
  int SubWord(int, const int*);     
        
  
  /* R */
  int RotWord(int);                
  void run();

  SC_CTOR (aes){
     SC_CTHREAD(run,clk.pos());
     reset_signal_is(rst,false);
  }

  ~aes(){};


};


#endif // AES_H
