/*
*This software program and documentation are copyrighted by The Hong Kong Polytechnic University. 
*The software program and documentation are supplied ��as *is��, without any accompanying services 
*from The University. The University does not warrant that the operation of the program will be 
*uninterrupted or error-free.The end-user understands that the program was developed for research 
*purposes and is advised not to rely exclusively on the program for any reason.
*
*IN NO EVENT SHALL THE HONG KONG POLYTECHNIC UNIVERSITY BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT, SPECIAL, 
*INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS 
*DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN AD- VISED OF THE POSSIBILITY OF SUCH DAMAGE. THE HONG 
*KONG POLYTECHNIC UNIVERSITY SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
*WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED HEREUNDER IS ON AN ��AS IS�� 
*BASIS, AND THE HONG KONG POLYTECHNIC UNIVERSITY HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, 
*ENHANCEMENTS, OR MODIFICATIONS.
*/
//========================================================================================
// 
// File Name    : filter_interp.h
// Description  : Main interpolation filter component declaration
// Release Date : 23/07/2013
// Author       : PolyU DARC Lab
//                Benjamin Carrion Schafer, Anushree Mahapatra ,Xu Siyuan
//
// Revision History
//---------------------------------------------------------------------------------------
// Date       Version   Author      Description
//----------------------------------------------------------------------------------------
//23/07/2013   1.0      PolyU       Interpolation filter declaration file
//=======================================================================================

#ifndef INTERP_H_
#define INTERP_H_

#define SC_INCLUDE_FX

#include "define.h"


SC_MODULE (interp) {

public:
   
  // Inputs
   sc_in_clk clk;
   sc_in<bool> rst;
      //inputs
 // sc_in <  sc_fixed<16,1,SC_TRN,SC_WRAP>  > UUT_in;
 sc_in <  sc_int<32>  > UUT_in;
  sc_in <bool > input_valid_signal;
  sc_in <bool > output_control_signal;
  //outputs
//  sc_out< sc_fixed<16,1,SC_RND,SC_SAT> > UUT_out;
  sc_out< sc_int<32> > UUT_out;
  sc_out  <bool > output_valid_signal;
/*
   // Inputs
   sc_in< sc_fixed<16,1,SC_TRN,SC_WRAP> > indata;
   sc_in< sc_ufixed<9,0,SC_TRN,SC_WRAP> > infactor;
  

   // Output   
   sc_out< bool > odata_en;
   sc_out< sc_fixed<16,1,SC_RND,SC_SAT> > odata;
*/
   // Variables
   sc_fixed<16,1,SC_TRN,SC_WRAP> buffer[TAPS] ;

  sc_fixed<16,1,SC_TRN,SC_WRAP> indata_read;
  sc_ufixed<9,0,SC_TRN,SC_WRAP> infactor_read;
  sc_fixed<16,1,SC_RND,SC_SAT> odata_write;


   sc_fixed<36,6,SC_TRN,SC_WRAP> SoP1;
   sc_fixed<36,6,SC_TRN,SC_WRAP> SoP2;
   sc_fixed<36,6,SC_TRN,SC_WRAP> SoP3;
   sc_fixed<36,6,SC_TRN,SC_WRAP> SoP4;

  // Functions declarations


   /* R */
   void run (void);

  
   SC_CTOR (interp) {
      SC_CTHREAD (run, clk.pos());
      reset_signal_is (rst, false );
   }

   ~interp() {}


}; 

#endif //  INTERP_H_
