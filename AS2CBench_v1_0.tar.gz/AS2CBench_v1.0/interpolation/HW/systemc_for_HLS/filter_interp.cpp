/*
*This software program and documentation are copyrighted by The Hong Kong Polytechnic University. 
*The software program and documentation are supplied ��as *is��, without any accompanying services 
*from The University. The University does not warrant that the operation of the program will be 
*uninterrupted or error-free.The end-user understands that the program was developed for research 
*purposes and is advised not to rely exclusively on the program for any reason.
*
*IN NO EVENT SHALL THE HONG KONG POLYTECHNIC UNIVERSITY BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT, SPECIAL, 
*INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS 
*DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN AD- VISED OF THE POSSIBILITY OF SUCH DAMAGE. THE HONG 
*KONG POLYTECHNIC UNIVERSITY SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
*WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED HEREUNDER IS ON AN ��AS IS�� 
*BASIS, AND THE HONG KONG POLYTECHNIC UNIVERSITY HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, 
*ENHANCEMENTS, OR MODIFICATIONS.
*/
//========================================================================================
// 
// File Name    : filter_interp.cpp
// Description  : Main interpolation filter function
// Release Date : 23/07/2013
// Author       : PolyU DARC Lab
//                Benjamin Carrion Schafer, Anushree Mahapatra ,Xu Siyuan
//
// Revision History
//---------------------------------------------------------------------------------------
// Date         Version   Author      Description
//----------------------------------------------------------------------------------------
//23/07/2013     1.0      PolyU      Interpolation filter description
//=======================================================================================
#include "filter_interp.h"


void interp::run ( void ) {

 int x,y;
 bool input_valid_compare,input_valid_read;
 bool output_control_compare,output_control_read;
  unsigned int n;

   const sc_fixed<17,2,SC_TRN,SC_WRAP> coeff1[TAPS] = {0.002561105374,
						       -0.0374560342,
						       0.261339038123,
						       0.236616189234,
						       -0.0175371872,
						       0.003662109373,
						       0.040705008125,
						       -0.0063781875};

   const sc_fixed<17,2,SC_TRN,SC_WRAP> coeff2[TAPS] = {-0.0012220704128,
						       -0.00992526286873,
						        0.28326416015625,
						       -0.38756410156234,
						        0.01092529296875,
						        0.0111770703125,
						       -0.01092529296875,
						       0.28326416015625};

   const sc_fixed<17,2,SC_TRN,SC_WRAP> coeff3[TAPS] = {-0.0254359140667,
						       0.12369433597894,
						       -0.08766552334675,
						       -0.08944552734377,
						       0.4443443359323,
						       -0.0172119140625,
						       0.1116943359375,
						       0.2222743352321};

   const sc_fixed<17,2,SC_TRN,SC_WRAP> coeff4[TAPS] = {-0.022432453112228,
						        0.056155029296845,
						       -0.562341259765625,
						        0.34291256765612,
						       -0.078155029296811,
						        0.003434129453125,
						        0.045560371453428,
						        0.00014556453135};
 //  odata_en = 0;
 //  odata = 0;

   wait();

   while (1) {

      // Read inputs
  //    indata_read = indata.read();
     // infactor_read = infactor.read();
      //inputs
     while(1){

	input_valid_read=input_valid_signal.read();
	if(input_valid_compare!=input_valid_read)
                             {
		output_valid_signal.write(false); 		
		x++;
		input_valid_compare=input_valid_read;	
	                  }
		if(x==2)  		//detect that is an pulse 
		{    
			 x=0;	 	 
			indata_read =(UUT_in.read()/1000000.0);
			 break;	
		}	

	wait();
	}
//inputs
     while(1){

	input_valid_read=input_valid_signal.read();
	if(input_valid_compare!=input_valid_read)
                             {
		output_valid_signal.write(false); 		
		x++;
		input_valid_compare=input_valid_read;	
	                  }
		if(x==2)  		//detect that is an pulse 
		{    
			 x=0;	 	 
			infactor_read=(UUT_in.read()/1000000.0);
			 break;	
		}	

	wait();
	}
   //   odata_en.write(0);

    // Read inputs by shifting previous data
    for ( n = 5; n>0; n--)
         buffer[n] = buffer[n-1];
      buffer[0] = indata_read;
  
   
      // FIR 1 : Sum of Products of 1st filter
      SoP1 = 0;
      for (n = 0; n < TAPS; n++ ) 
	SoP1 = SoP1 + buffer[n] * coeff1[n];
      
      // FIR 2 : Sum of Products of 2nd filter
      SoP2 = 0;
      for (n = 0; n < TAPS; n++ ) 
	SoP2 =SoP2 + buffer[n] * coeff2[n];

      // FIR 3 : Sum of Products of 3rd filter
      SoP3 = 0;
      for ( n = 0; n < TAPS; n++ ) 
	SoP3 = SoP3 + buffer[n] * coeff3[n];

      // FIR 4 : Sum of Products of 4th filter
      SoP4 = 0;
      for (n = 0; n < TAPS; n++ ) 
	SoP4 = SoP4 + buffer[n] * coeff4[n];


   // Output computation 
   odata_write = SoP1 +
               SoP2 * infactor_read +
               SoP3 * infactor_read*infactor_read + 
               SoP4 * infactor_read*infactor_read*infactor_read;

   // Manual polynomial decomposition (reduces the number of arithmetic operations -> leads to smaller design)
//	tmp1 = SoP4*infactor_read + SoP3;
//	tmp2 = tmp1 * infactor_read + SoP2;
//    	odata_write = tmp2 * infactor_read + SoP1;


     // Write results back
  //    odata_en.write( 1 );
   //   odata.write( odata_write );
      //outputs  
     output_valid_signal.write(true); 
     while(1){

	output_control_read=output_control_signal.read();

	if(output_control_compare!=output_control_read)
                             {		
		x++;
		output_control_compare=output_control_read;	
	                  }
		if(x==2)  		//detect that is an pulse 
		{    
			 x=0;	 	 
			 UUT_out.write((sc_int<32>)(odata_write*1000000));
			break;
		}	

	wait();
	}
     output_valid_signal.write(false); 
      wait();
   }
}

