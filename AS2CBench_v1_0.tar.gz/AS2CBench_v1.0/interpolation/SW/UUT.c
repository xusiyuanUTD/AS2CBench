/*
*This software program and documentation are copyrighted by The Hong Kong Polytechnic University. 
*The software program and documentation are supplied ��as *is��, without any accompanying services 
*from The University. The University does not warrant that the operation of the program will be 
*uninterrupted or error-free.The end-user understands that the program was developed for research 
*purposes and is advised not to rely exclusively on the program for any reason.
*
*IN NO EVENT SHALL THE HONG KONG POLYTECHNIC UNIVERSITY BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT, SPECIAL, 
*INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS 
*DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN AD- VISED OF THE POSSIBILITY OF SUCH DAMAGE. THE HONG 
*KONG POLYTECHNIC UNIVERSITY SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
*WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED HEREUNDER IS ON AN ��AS IS�� 
*BASIS, AND THE HONG KONG POLYTECHNIC UNIVERSITY HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, 
*ENHANCEMENTS, OR MODIFICATIONS.
*/
//========================================================================================
// 
// File Name    : UUT.c
// Description  : Main testbench file
// Author       : PolyU DARC Lab
//                Benjamin Carrion Schafer, Xu Siyuan
// 
//
//=======================================================================================

#include "define.h"
#include <stdio.h>
#include <unistd.h>
#include "hwlib.h"
#include "socal/socal.h"
#include "socal/hps.h"
#include "socal/alt_gpio.h"
#include <malloc.h>
#include "stdlib.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <sys/mman.h>
#include "hps_0.h"
#include <stdbool.h>

#define HW_REGS_BASE ( ALT_STM_OFST )
#define HW_REGS_SPAN ( 0x04000000 )
#define HW_REGS_MASK ( HW_REGS_SPAN - 1 )

 volatile unsigned long *h2p_lw_UUT_addr;
 volatile unsigned long *h2p_lw_outvalid_addr;

  // Variables declaration
  FILE *fptr_data;
  FILE *in_file_data, *in_file_factor;


//--------------------------------
// Compare simulation results vs. golden output
//--------------------------------

void compare_results(void){

  // Variables declaration
  float outfilter_golden,outfilter;
  int errors, line;
  FILE *out_fil_golden;
 

  fclose(fptr_data);

  fptr_data = fopen(OUT_FILE, "rt");
 
  line =0;
  errors = 0;



  out_fil_golden = fopen(GOLDEN_OUTPUT , "rt");

  if(!out_fil_golden){
    printf( "Could not open  GOLDEN_OUTPUT \n" );
  }
  

  while(fscanf(out_fil_golden, "%f", &outfilter_golden)!= EOF && fscanf(fptr_data, "%f", &outfilter) != EOF ){
 
    if(outfilter!= outfilter_golden){
      errors++;
    }

    line++;

  }



   if(errors == 0)
     printf("Finished simulation SUCCESSFULLY \n" );
    else
    printf("MISSMATCHES between Golden and Simulation \n" );


  fclose(out_fil_golden);
  fclose(fptr_data);
}



//----------------------
// Send data to Interpolation Filter
//----------------------------
void send(void){

  // Variables declarations
  float indata_var;
  float  infactor_var;
  int indata_int;
  unsigned int infactor_int;
  int k;
  int z;
  int read;
   int odata_rcv;
   float outdata;

  fptr_data = fopen(OUT_FILE , "wt");

 
  if(!fptr_data){
   printf(" could not be opened output \n" );
 
  }


   //Reset initialization
   in_file_data = fopen(IN_DATA, "r");
   in_file_factor = fopen( IN_FACTOR_DATA, "r");

   if(!in_file_data){
     printf( "data file could not be opened \n");
    }

   if(!in_file_factor){
     printf( " file could not be opened \n " );;

   }



    while(fscanf(in_file_data,"%f",&indata_var) !=EOF &&  fscanf(in_file_factor,"%f", &infactor_var) != EOF){
     
    //  indata.write(indata_var);
     // infactor.write(infactor_var);
	indata_int=indata_var*1000000;
	
	infactor_int=infactor_var*1000000;
	alt_write_word(h2p_lw_UUT_addr,indata_int);
	alt_write_word(h2p_lw_UUT_addr,infactor_int);
      //  printf("indata_int is %d\n",indata_int);
	// printf("incoeff_int is %d\n",infactor_int);
	while(1)	{
  	 		 read=alt_read_word(h2p_lw_outvalid_addr);
		
			if(read==1)
			{
			 alt_write_word(h2p_lw_outvalid_addr,true);
   			 odata_rcv = alt_read_word(h2p_lw_UUT_addr);
			 outdata=odata_rcv/1000000.0;
			 fprintf(fptr_data,"%f\n",outdata);
			// printf("output is %d\n",odata_rcv);
			 break;
		
			}
	
			}
    }


    fclose(in_file_data);
    fclose(in_file_factor);
   
    printf( "Start comparing results \n ");
    compare_results();




 

}

//--------------------------
// Main function
//--------------------------


int main(int argc, char **argv)
{


	void *virtual_base;
	int fd;
	
   	double elapsed;

	// map the address space for the LED registers into user space so we can interact with them.
	// we'll actually map in the entire CSR span of the HPS since we want to access various registers within that span
	if( ( fd = open( "/dev/mem", ( O_RDWR | O_SYNC ) ) ) == -1 ) {
		printf( "ERROR: could not open \"/dev/mem\"...\n" );
		return( 1 );
	}
	virtual_base = mmap( NULL, HW_REGS_SPAN, ( PROT_READ | PROT_WRITE ), MAP_SHARED, fd, HW_REGS_BASE );	
	if( virtual_base == MAP_FAILED ) {
		printf( "ERROR: mmap() failed...\n" );
		close( fd );
		return(1);
	}
	h2p_lw_UUT_addr=virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + UUT_IO_BASE) & ( unsigned long)( HW_REGS_MASK ) );
	h2p_lw_outvalid_addr=virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + OUTPUT_VALID_BASE ) & ( unsigned long)( HW_REGS_MASK ) );
	

  	time_t end,start=time(NULL);
		send();
  	end = time(NULL);
    	elapsed = difftime(end, start);
  	printf("\n\nRunning time %10.4f\n", elapsed);

	if( munmap( virtual_base, HW_REGS_SPAN ) != 0 ) {
		printf( "ERROR: munmap() failed...\n" );
		close( fd );
		return( 1 );

	}
	close( fd );
	return 0;
}
