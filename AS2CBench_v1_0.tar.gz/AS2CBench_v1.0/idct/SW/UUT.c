/*
*This software program and documentation are copyrighted by The Hong Kong Polytechnic University. 
*The software program and documentation are supplied ��as *is��, without any accompanying services 
*from The University. The University does not warrant that the operation of the program will be 
*uninterrupted or error-free.The end-user understands that the program was developed for research 
*purposes and is advised not to rely exclusively on the program for any reason.
*
*IN NO EVENT SHALL THE HONG KONG POLYTECHNIC UNIVERSITY BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT, SPECIAL, 
*INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS 
*DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN AD- VISED OF THE POSSIBILITY OF SUCH DAMAGE. THE HONG 
*KONG POLYTECHNIC UNIVERSITY SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
*WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED HEREUNDER IS ON AN ��AS IS�� 
*BASIS, AND THE HONG KONG POLYTECHNIC UNIVERSITY HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, 
*ENHANCEMENTS, OR MODIFICATIONS.
*/
//========================================================================================
// 
// File Name    : test_bench
// Author       : PolyU DARC Lab
//                Benjamin Carrion Schafer, Xu Siyuan
// 
//
//=======================================================================================


#include <stdio.h>
#include <unistd.h>
#include "hwlib.h"
#include "socal/socal.h"
#include "socal/hps.h"
#include "socal/alt_gpio.h"
#include <malloc.h>
#include "stdlib.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <sys/mman.h>
#include "hps_0.h"
#include <stdbool.h>
#include <math.h>
#include "define.h"

#define HW_REGS_BASE ( ALT_STM_OFST )
#define HW_REGS_SPAN ( 0x04000000 )
#define HW_REGS_MASK ( HW_REGS_SPAN - 1 )

 volatile unsigned long *h2p_lw_UUT_addr;
 volatile unsigned long *h2p_lw_outvalid_addr;


  //For data feeding
  FILE * in_file, *in_file_coef, *out_file_golden, *out_file, *diff_file;



//---------------------------
// Compare results function
//---------------------------
void compare_results(){

  //unsigned int out_idct, out_golden;
   int out_idct, out_golden;
  int  line=1, errors=0;

  // Close file where outputs are stored
  fclose(out_file);


  // Open results file
  out_file = fopen (OUTFILENAME, "rt");
  if(!out_file){
    printf(  "Could not open  OUTFILENAME \n ");
  }



  //
  // Load the golden pattern
  //
  out_file_golden = fopen (OUTFILENAME_GOLDEN, "rt");
  if(!out_file_golden){
    printf( "Could not open OUTFILENAME_GOLDEN \n ");

  }


    //
    // Dump the comparison result
    //
    diff_file = fopen (DIFFFILENAME, "w");
    if(!diff_file){
	 printf(  "Could not open  DIFFFILENAME \n ") ;
	 
       }

    while(fscanf(out_file_golden, "%u", &out_golden) != EOF){

      if(fscanf(out_file,"%d", &out_idct) == EOF)
	break;

      if(out_idct != out_golden ){
	
	fprintf(diff_file,"\nOutput missmatch[line:%d] Golden: %d -- Output: %d",line, out_golden, out_idct);   
	errors++;
      }
      
      line ++;

    }

    if(errors == 0)
      printf( "Finished simulation SUCCESSFULLY \n ") ;
    else
      printf(  " MISSMATCHES between Golden and Simulation \n "); 


    fclose(out_file);
    fclose(diff_file);
    fclose(out_file_golden);



}

//-------------------
// Send data thread
//------------------
void send(){

  // Variables declaration
  int ret1=0, ret2=0,x,read,ctr;
  unsigned int  indata, incoef;

  // Variables declaration
  unsigned int out_sample[8], out_row[8], out_col[8];
  int j=0;
  out_file = fopen (OUTFILENAME, "wt");

  if(!out_file){
    printf(  "Could not open OUTFILENAME \n ");
    exit (-1);
  }


  // open input data files
  in_file = fopen(INFILENAME, "rt");

  if(!in_file){
    printf(  "Could not open  INFILENAME \n ");
  }


  in_file_coef = fopen(INFILENAME_COEF, "rt");

  if(!in_file){
    printf(  "Could not open  INFILENAME_COEF \n " );
  }



while(1) 
    
{

  for (ctr = DCTSIZE; ctr > 0; ctr--) {

   for(x=0; x< 8; x++){

	  ret1 = fscanf(in_file,"%u", &indata);
	  if(ret1 == EOF){
	  break;
	  }
	  alt_write_word(h2p_lw_UUT_addr,indata); 
		}


      for(x=0; x< 8; x++){
	  ret2 = fscanf(in_file_coef,"%u", &incoef);
	  if(ret2 == EOF){
	    break;
	  }
	 alt_write_word(h2p_lw_UUT_addr,incoef);
	}


}  
      if(ret1 == EOF || ret2 == EOF) break;

	
    for (ctr = 0; ctr < DCTSIZE; ctr++) {
	
	while(1)	{
  	 		 read=alt_read_word(h2p_lw_outvalid_addr);

			if(read==1)
			{
   			
		for ( j = 0; j < 8; j++ ) {
		alt_write_word(h2p_lw_outvalid_addr,true);
		out_col[j]=alt_read_word(h2p_lw_UUT_addr);
		}
		for ( j = 0; j < 8; j++ ) {
		alt_write_word(h2p_lw_outvalid_addr,true);
		out_row[j]=alt_read_word(h2p_lw_UUT_addr);
		}
		for ( j = 0; j < 8; j++ ) {
		alt_write_word(h2p_lw_outvalid_addr,true);
		out_sample[j]=alt_read_word(h2p_lw_UUT_addr);
		}
		for ( j = 0; j < 8; j++ ) {

     		fprintf(out_file,"%u %u %u\n",  out_row[j], out_col[j], out_sample[j]); 
		}
		break;
			}
			}
					}
	

}//end

  



    fclose(in_file);
    fclose(in_file_coef);

    printf(  "Starting comparing results \n ");
 
    compare_results();



}







//--------------------------
// Main function
//--------------------------


int main(int argc, char **argv)
{


	void *virtual_base;
	int fd;
	//int i;
   	double elapsed;

	// map the address space for the LED registers into user space so we can interact with them.
	// we'll actually map in the entire CSR span of the HPS since we want to access various registers within that span
	if( ( fd = open( "/dev/mem", ( O_RDWR | O_SYNC ) ) ) == -1 ) {
		printf( "ERROR: could not open \"/dev/mem\"...\n" );
		return( 1 );
	}
	virtual_base = mmap( NULL, HW_REGS_SPAN, ( PROT_READ | PROT_WRITE ), MAP_SHARED, fd, HW_REGS_BASE );	
	if( virtual_base == MAP_FAILED ) {
		printf( "ERROR: mmap() failed...\n" );
		close( fd );
		return(1);
	}

	h2p_lw_UUT_addr=virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + UUT_IO_BASE) & ( unsigned long)( HW_REGS_MASK ) );
	h2p_lw_outvalid_addr=virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + OUTPUT_VALID_BASE ) & ( unsigned long)( HW_REGS_MASK ) );

	

	printf("\n starting simualtion \n ");


  	time_t end,start=time(NULL);
		send();
  	end = time(NULL);
    	elapsed = difftime(end, start);
  	printf("\n\nRunning time %10.4f\n", elapsed);


	if( munmap( virtual_base, HW_REGS_SPAN ) != 0 ) {
		printf( "ERROR: munmap() failed...\n" );
		close( fd );
		return( 1 );

	}
	close( fd );
	return 0;
}
