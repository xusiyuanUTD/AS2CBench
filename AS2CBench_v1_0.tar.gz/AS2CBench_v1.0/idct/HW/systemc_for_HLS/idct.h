/*
*This software program and documentation are copyrighted by The Hong Kong Polytechnic University. 
*The software program and documentation are supplied ��as *is��, without any accompanying services 
*from The University. The University does not warrant that the operation of the program will be 
*uninterrupted or error-free.The end-user understands that the program was developed for research 
*purposes and is advised not to rely exclusively on the program for any reason.
*
*IN NO EVENT SHALL THE HONG KONG POLYTECHNIC UNIVERSITY BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT, SPECIAL, 
*INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS 
*DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN AD- VISED OF THE POSSIBILITY OF SUCH DAMAGE. THE HONG 
*KONG POLYTECHNIC UNIVERSITY SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
*WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED HEREUNDER IS ON AN ��AS IS�� 
*BASIS, AND THE HONG KONG POLYTECHNIC UNIVERSITY HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, 
*ENHANCEMENTS, OR MODIFICATIONS.
*/
//========================================================================================
// 
//
// File Name    : idct.h
// Description  : IDCT
// Release Date : 31/07/2013
//
//
// Revision History
//---------------------------------------------------------------------------------------
// Date        Author      Version      Description
//----------------------------------------------------------------------------------------
//  1991-1998  Thomas G. Lange 1.0      Origiinal IDCT implementation    
//  31/07/2013  PolyU          1.1      Converted into Synthesizable SystemC                 
//
//=======================================================================================


#ifndef IDCT_H_
#define IDCT_H_

#include "define.h"

SC_MODULE( idct ) {

  typedef int        workspace_t;

  // Inputs
  sc_in_clk              clk;
  sc_in< bool >          rst;


//  sc_in< sc_int<16>  >   input_coef;
//  sc_in< sc_uint<6>  >   input_quant;

  // Outputs
  //sc_out< bool >         output_start;
 // sc_out< sc_uint<8>  >  output_sample;
 // sc_out< sc_uint<3> >   output_row;
  //sc_out< sc_uint<3> >   output_col;

   //inputs
  sc_in <sc_int <16> > UUT_in;
  sc_in <bool > input_valid_signal;
  sc_in <bool > output_control_signal;
  //outputs
  sc_out<sc_uint<8> > UUT_out;
  sc_out  <bool > output_valid_signal;

  /* E */
  void entry();

  /* J */
  void jpeg_idct_islow();

  /* R */
  void run();
  


  SC_CTOR( idct ) {
      SC_CTHREAD(run, clk.pos());
      reset_signal_is(rst, false);
  };



    ~idct(){};

};

#endif // IDCT_H_
