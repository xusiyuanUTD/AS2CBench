/*
*This software program and documentation are copyrighted by The Hong Kong Polytechnic University. 
*The software program and documentation are supplied ��as *is��, without any accompanying services 
*from The University. The University does not warrant that the operation of the program will be 
*uninterrupted or error-free.The end-user understands that the program was developed for research 
*purposes and is advised not to rely exclusively on the program for any reason.
*
*IN NO EVENT SHALL THE HONG KONG POLYTECHNIC UNIVERSITY BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT, SPECIAL, 
*INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS 
*DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN AD- VISED OF THE POSSIBILITY OF SUCH DAMAGE. THE HONG 
*KONG POLYTECHNIC UNIVERSITY SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
*WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED HEREUNDER IS ON AN ��AS IS�� 
*BASIS, AND THE HONG KONG POLYTECHNIC UNIVERSITY HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, 
*ENHANCEMENTS, OR MODIFICATIONS.
*/
//---------------------------------------------------------------------------
//
// File Name    : qsort.cpp
// Description  : Quick sort implementation
// Release Date : 01/08/13
// Author       : PolyU DARC Lab
//                Benjamin Carrion Schafer, Anushree Mahapatra, Xu Siyuan
//
// Revision History
//---------------------------------------------------------------------------
// Date       Version   Author               Description
//---------------------------------------------------------------------------
//            1.0       Darel Rex Finley   Initial version. This public-domain C implementation by
// 01/08/13   1.1       PolyU DARC Lab   Conversion into Synthesizable SystemC
//---------------------------------------------------------------------------

#include "qsort.h"


void quicksort::run(){
	
  sc_uint<8>  data[SIZE], data_out[SIZE];
//  int x,n,m;
 int x,y;
 bool input_valid_compare,input_valid_read;
 bool output_control_compare,output_control_read;

  wait();

  while(1){
/*
     for(x = 0 ; x < SIZE ; x++){
       data[x] = indata.read() ;
       odata.write(data_out[x]);
       wait();
     }
*/
 
//inputs
     while(1){

	input_valid_read=input_valid_signal.read();
	if(input_valid_compare!=input_valid_read)
                             {
		output_valid_signal.write(false); 		
		x++;
		input_valid_compare=input_valid_read;	
	                  }
		if(x==2)  		//detect that is an pulse 
		{    
			 x=0;	 	 
			 data[y]=UUT_in.read();
			 y++; 
		}	

		if(y==SIZE)
		{
 			y=0;
			break;	
		}
	wait();
	}

     // Main quick sort routine 
     sort(data);

		

 //    UUT_out.write(data[SIZE-1]);
   //  output_valid_signal.write(true); 
//outputs  
     output_valid_signal.write(true); 
     while(1){

	output_control_read=output_control_signal.read();

	if(output_control_compare!=output_control_read)
                             {		
		x++;
		output_control_compare=output_control_read;	
	                  }
		if(x==2)  		//detect that is an pulse 
		{    
			 x=0;	 	 
			 UUT_out.write(data[y]);
			 y++; 
		}	

		if(y==SIZE)
		{
 			y=0;
			break;	
		}
	wait();
	}
     output_valid_signal.write(false); 
        wait() ;
  }

}

//--------------------------
// Main sorting function
//-------------------------
void quicksort::sort(sc_uint<8> *arr){


  // Variables declaration
  int  piv, beg[SIZE], end[SIZE], i=0, L, R;

  beg[0]=0;
  end[0]=SIZE;

  while (i>=0) {
    
    L=beg[i]; R=end[i]-1;
    if (L<R) {
      piv=arr[L];
    
      while (L<R) {
        while (arr[R]>=piv && L<R)
	  R--;
	if (L<R)
	  arr[L++]=arr[R];
       
	while (arr[L]<=piv && L<R)
	  L++;
	if(L<R) 
	  arr[R--]=arr[L];
      }
      
      arr[L]=piv;
      beg[i+1]=L+1;
      end[i+1]=end[i];
      end[i++]=L;
      
      if (end[i]-beg[i]>end[i-1]-beg[i-1]){
	swap(&end[i], &beg[i]);

      }
    } 

    else{
      i--;
    }
  } // end while

}


void quicksort::swap(int *end, int *beg){

  int swap;
  
  swap=*beg;
  *beg=*(beg-1);
  *(beg-1)=swap;

  swap=*end;
  *end=*(end-1); 
  *(end-1)=swap; 



}
