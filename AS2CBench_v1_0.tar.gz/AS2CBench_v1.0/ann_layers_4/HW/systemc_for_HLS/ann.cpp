/*
*This software program and documentation are copyrighted by The Hong Kong Polytechnic University. 
*The software program and documentation are supplied ��as *is��, without any accompanying services 
*from The University. The University does not warrant that the operation of the program will be 
*uninterrupted or error-free.The end-user understands that the program was developed for research 
*purposes and is advised not to rely exclusively on the program for any reason.
*
*IN NO EVENT SHALL THE HONG KONG POLYTECHNIC UNIVERSITY BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT, SPECIAL, 
*INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS 
*DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN AD- VISED OF THE POSSIBILITY OF SUCH DAMAGE. THE HONG 
*KONG POLYTECHNIC UNIVERSITY SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
*WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED HEREUNDER IS ON AN ��AS IS�� 
*BASIS, AND THE HONG KONG POLYTECHNIC UNIVERSITY HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, 
*ENHANCEMENTS, OR MODIFICATIONS.
*/
//========================================================================================
// 
// File Name    : ann.cpp
// Description  : ANN main file
// Release Date : 22/10/2014
// 
//
// Revision History
//---------------------------------------------------------------------------------------
// Date         Version         Author                      Description
//----------------------------------------------------------------------------------------
// 2014          1.0            David Aledo, UPM             Artificial Neural Network 
//
//=======================================================================================

#include "ann.h"

/* Constructors */
ann::ann(sc_module_name nm) : sc_module(nm)
{
   SC_CTHREAD(Wyb_cthread, clk.pos());
      reset_signal_is(rst,false);

   SC_CTHREAD(ann_cthread, clk.pos());
      reset_signal_is(rst,false);
}


void ann::Wyb_cthread()
{
   /* Memories do not need initialization */

   wait();

   for(;;)
   {

#ifdef NLAYER_4
         write_Wyb< type_0 >(layer_0, 0);
         write_Wyb< type_1 >(layer_1, 1);
         write_Wyb< type_2 >(layer_2, 2);
         write_Wyb< type_3 >(layer_3, 3);
#else
         write_Wyb< type_0 >(layer_0, 0);
         write_Wyb< type_1 >(layer_1, 1);
#endif
wait();

   }
}

template <class Lt>
void ann::write_Wyb(Lt &Wyb, int l){
int n,x,y;
 bool wr_valid_compare,wr_valid_read;

   /* Write weights first */
     while(1){
	wr_valid_read=wr_valid_signal.read();
	if(wr_valid_compare!=wr_valid_read)
                             {		
		n++;
		wr_valid_compare=wr_valid_read;	
	                  }
		if(n==2)  		//detect that is an pulse 
		{    
			n=0;	 	 
			 Wyb.W[x][y] = wdata.read();
			 y++; 
		}	

		if(y==NumN[l])
		{
 			y=0;
			x++;
		}
		if(x==NumN[l+1])
		{
 			x=0;
			break;
		}
	wait();
	}

   /* Write biases second */
 x=0;
 y=0;

 while(1){
	wr_valid_read=wr_valid_signal.read();
	if(wr_valid_compare!=wr_valid_read)
                             {		
		n++;
		wr_valid_compare=wr_valid_read;	
	                  }
		if(n==2)  		//detect that is an pulse 
		{    
			n=0;	 	 
			 Wyb.b[y] = wdata.read();
			 y++; 
		}	

		if(y==NumN[l+1])
		{
 			y=0;
			break;
		}

	wait();
	}

}


/***************************
 **
 ** Main ANN SC_CThread
 **
 ***************************/
void ann::ann_cthread(){

 int x,y;
 bool input_valid_compare,input_valid_read;
 bool output_control_compare,output_control_read;

  /* Reset condition */

   wait();

   /* Main loop */
   //for(;;)
  // {
      while(1){


         /* 1.)  Read inputs to buffer */
/*
         for(int i=0; i<NumN[0]; i++)
         {
            buff[0][i] = inputs[i]->read();
         }
*/

//inputs
     while(1){

	input_valid_read=input_valid_signal.read();
	if(input_valid_compare!=input_valid_read)
                             {
		output_valid_signal.write(false); 		
		x++;
		input_valid_compare=input_valid_read;	
	                  }
		if(x==2)  		//detect that is an pulse 
		{    
			 x=0;	 	 
			 buff[0][y]=UUT_in.read();
			 y++; 
		}	

		if(y==NumN[0])
		{
 			y=0;
			break;	
		}
	wait();
	}
         /* 2.) Calls to the layer function: */
#ifdef NLAYER_4
	layer< type_0 >(layer_0, 0);
	layer< type_1 >(layer_1, 1);
	layer< type_2 >(layer_2, 2);
	layer< type_3 >(layer_3, 3);
#else
	layer< type_0 >(layer_0, 0);
	layer< type_1 >(layer_1, 1);
#endif

	 /* 3.) Write outputs */


     
//outputs  
 

//outputs  
     output_valid_signal.write(true); 
     while(1){
	 int clipp = buff[Nlayer][y];
	output_control_read=output_control_signal.read();

	if(output_control_compare!=output_control_read)
                             {		
		x++;
		output_control_compare=output_control_read;	
	                  }
		if(x==2)  		//detect that is an pulse 
		{    
			 x=0;	
		    if (clipp >= 1<<(NbitOut-1))  	 
			 UUT_out.write((1<<(NbitOut-1))-1);
		    else if (clipp <= -1<<(NbitOut-1))
		   	UUT_out.write(-1<<(NbitOut-1) );
		   else
			 UUT_out.write(clipp);
			 y++; 
		}	

		if(y==NumN[Nlayer])
		{
 			y=0;
			break;	
		}
	wait();
	}
     output_valid_signal.write(false); 

         wait();
} // for loop  }
}

template <class Lt>
void ann::layer(Lt &Wyb, int l)
{
   for(int n=0; n<NumN[l+1]; n++) //Important: Order of nested loops for inputs and neurons
   {
     signed int acc = Wyb.b[n]; //bias
      for(int i=0; i<NumN[l]; i++)
      {
         acc += buff[l][i]*Wyb.W[n][i];
      }
      buff[l+1][n] = acc>>trunc_out;
   }
}



