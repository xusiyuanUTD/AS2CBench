/*
*This software program and documentation are copyrighted by The Hong Kong Polytechnic University. 
*The software program and documentation are supplied ��as *is��, without any accompanying services 
*from The University. The University does not warrant that the operation of the program will be 
*uninterrupted or error-free.The end-user understands that the program was developed for research 
*purposes and is advised not to rely exclusively on the program for any reason.
*
*IN NO EVENT SHALL THE HONG KONG POLYTECHNIC UNIVERSITY BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT, SPECIAL, 
*INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS 
*DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN AD- VISED OF THE POSSIBILITY OF SUCH DAMAGE. THE HONG 
*KONG POLYTECHNIC UNIVERSITY SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
*WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED HEREUNDER IS ON AN ��AS IS�� 
*BASIS, AND THE HONG KONG POLYTECHNIC UNIVERSITY HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, 
*ENHANCEMENTS, OR MODIFICATIONS.
*/
//========================================================================================
// 
// File Name    : ann.h
// Description  : 
// Release Date : 22/10/2014
// 
//
// Revision History
//---------------------------------------------------------------------------------------
// Date         Version         Author          Description
//----------------------------------------------------------------------------------------
// 2014          1.0            David Aledo    ANN header
//
//=====================================================================================

#ifndef ANN_H
#define ANN_H

/* Parameters */
#include "synth_param.h"
#include "config.h"

#include <systemc.h>

#ifdef TRAIN
extern int *a[Nlayer-1]; //global variable for training
#endif

SC_MODULE(ann)
{
  // Inputs
   sc_in< bool > clk;
   sc_in< bool > rst;


   sc_in< sc_int<NbitW> > wdata;
   sc_in< bool > wr_valid_signal;
   //inputs
  sc_in <sc_int <NbitIn> > UUT_in;
  sc_in <bool > input_valid_signal;
  sc_in <bool > output_control_signal;
  //outputs
  sc_out<sc_int<NbitOut> > UUT_out;
  sc_out  <bool > output_valid_signal;



   /* Internal variables */
 signed  int buff[Nlayer+1][MAX_N] /* ATTR1 */; 

   /* Weight and bias declaration */

#ifdef NLAYER_4
   type_0 layer_0;
   type_1 layer_1;
   type_2 layer_2;
   type_3 layer_3;
#else
   type_0 layer_0;
   type_1 layer_1;
#endif


   /* Processes */
   /* A */
   void ann_cthread();


   /* L */
   template <class Lt>
   void layer(Lt &Wyb, int l);

   /* W */
   void Wyb_cthread();
   template <class Lt>
   void write_Wyb(Lt &Wyb, int l);


   /* Constructors */
   SC_HAS_PROCESS(ann);
   ann(sc_module_name nm);

   /* Destructor */
   //~ann();
};

#endif //ANN_H

