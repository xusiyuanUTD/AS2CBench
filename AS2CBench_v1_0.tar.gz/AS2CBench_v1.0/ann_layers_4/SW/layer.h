/*
*This software program and documentation are copyrighted by The Hong Kong Polytechnic University. 
*The software program and documentation are supplied ��as *is��, without any accompanying services 
*from The University. The University does not warrant that the operation of the program will be 
*uninterrupted or error-free.The end-user understands that the program was developed for research 
*purposes and is advised not to rely exclusively on the program for any reason.
*
*IN NO EVENT SHALL THE HONG KONG POLYTECHNIC UNIVERSITY BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT, SPECIAL, 
*INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS 
*DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN AD- VISED OF THE POSSIBILITY OF SUCH DAMAGE. THE HONG 
*KONG POLYTECHNIC UNIVERSITY SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
*WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED HEREUNDER IS ON AN ��AS IS�� 
*BASIS, AND THE HONG KONG POLYTECHNIC UNIVERSITY HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, 
*ENHANCEMENTS, OR MODIFICATIONS.
*/
//========================================================================================
// 
// File Name    : layer.h
// Description  : 
// Release Date : 22/10/2014
// 
//
// Revision History
//---------------------------------------------------------------------------------------
// Date         Version         Author          Description
//----------------------------------------------------------------------------------------
// 2014          1.0            David Aledo     Neuronal Network parameters
//
//=======================================================================================


#ifndef LAYER_H
#define LAYER_H

 struct layer
{

   bool initialized;

   unsigned int NumIn;
   unsigned int NumN;

   /* Dynamic memory */

  signed int **W;     // Weights
    float **DW;  // Weight increment for the next epoch
   signed int **Wprev; // Previous weights
   signed int *b;      // Bias
    float *Db;   // Bias increment for the next epoch
  signed int *bprev;  // Previous bias
 signed int *a;      // Output of each layer
   float *s;    // Sensibilities

};

   /* Constructors */
// void layer();   //Without initialization
 //void layer(unsigned int n_in, unsigned int n_n); //With initialization

   /* Methods */
 //  int initialize(unsigned int n_in, unsigned int n_n);
 //  inline bool is_initialized() {return initialized;}
 //  /*inline*/ unsigned int get_NumIn() {return NumIn;}
 //  /*inline*/ unsigned int get_NumN() {return NumN;}




#endif
