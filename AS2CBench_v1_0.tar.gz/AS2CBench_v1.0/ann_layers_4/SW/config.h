/*
*This software program and documentation are copyrighted by The Hong Kong Polytechnic University. 
*The software program and documentation are supplied ��as *is��, without any accompanying services 
*from The University. The University does not warrant that the operation of the program will be 
*uninterrupted or error-free.The end-user understands that the program was developed for research 
*purposes and is advised not to rely exclusively on the program for any reason.
*
*IN NO EVENT SHALL THE HONG KONG POLYTECHNIC UNIVERSITY BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT, SPECIAL, 
*INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS 
*DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN AD- VISED OF THE POSSIBILITY OF SUCH DAMAGE. THE HONG 
*KONG POLYTECHNIC UNIVERSITY SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
*WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED HEREUNDER IS ON AN ��AS IS�� 
*BASIS, AND THE HONG KONG POLYTECHNIC UNIVERSITY HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, 
*ENHANCEMENTS, OR MODIFICATIONS.
*/
//========================================================================================
// 
// File Name    : config.h
// Description  : 
// Release Date : 22/10/2014
// 
//
// Revision History
//---------------------------------------------------------------------------------------
// Date         Version         Author             Description
//----------------------------------------------------------------------------------------
// 2014          1.0            David Aledo        ANN configuration (2 layers)
// 2014          1.1            B Carrion Schafer  added 2 and 4 layer configuration
//
//=======================================================================================

#ifndef CONFIG_H
#define CONFIG_H

//#define NLAYER_4  // Uncomment for 4 layer version ANN
//#define PRINTD  // To print extra data like weights and bias



#define NumI 16 // Number of inputs
#define NumO 16 // Number of outputs
#define baseB 4 // Sqrt of NumI. It represents the side of the patches which the image is divided into

#define MAX_N 16

#ifdef NLAYER_2
	#define Nlayer 2
	const int NumN[Nlayer+1]={16,8,16};     // 2-Layer+1 output layer Editable

#else
	#define Nlayer 4
	const int NumN[Nlayer+1]={16,12,8,12,16};//4-layer+1 output layer. Editable
#endif

const int N_In;
const int N_N;

// struct synth_layer_data_16_12
//{
  // int W[12][16];
 //  int b[12];
//};

typedef struct synth_layer_data_16_8
{
   int W[8][16];
   int b[8];
}synth_layer_data_16_8;

typedef struct synth_layer_data_8_16
{
   int W[16][8];
   int b[16];
}synth_layer_data_8_16;

typedef struct synth_layer_data_16_12
{
   int W[12][16];
   int b[12];
}synth_layer_data_16_12;
typedef struct synth_layer_data_12_8
{
   int W[8][12];
   int b[8];
}synth_layer_data_12_8;

typedef struct synth_layer_data_8_12
{
   int W[12][8];
   int b[12];
}synth_layer_data_8_12;
typedef struct synth_layer_data_12_16
{
   int W[16][12];
   int b[16];
}synth_layer_data_12_16;


/* Layer types definitions */
#ifdef NLAYER_2
	synth_layer_data_16_8 type_0;
   	synth_layer_data_8_16 type_1;
#else
   
  // typedef synth_layer_data<16,12> type_0;
  // typedef synth_layer_data<12,8> type_1;
  // typedef synth_layer_data<8,12> type_2;
 //  typedef synth_layer_data<12,16> type_3;
	   synth_layer_data_16_12 type_0;
  	   synth_layer_data_12_8 type_1;
         synth_layer_data_8_12 type_2;
         synth_layer_data_12_16 type_3;

#endif

#endif
