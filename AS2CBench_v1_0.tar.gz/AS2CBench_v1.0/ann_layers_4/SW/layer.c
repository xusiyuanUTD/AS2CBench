/*
*This software program and documentation are copyrighted by The Hong Kong Polytechnic University. 
*The software program and documentation are supplied ��as *is��, without any accompanying services 
*from The University. The University does not warrant that the operation of the program will be 
*uninterrupted or error-free.The end-user understands that the program was developed for research 
*purposes and is advised not to rely exclusively on the program for any reason.
*
*IN NO EVENT SHALL THE HONG KONG POLYTECHNIC UNIVERSITY BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT, SPECIAL, 
*INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS 
*DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN AD- VISED OF THE POSSIBILITY OF SUCH DAMAGE. THE HONG 
*KONG POLYTECHNIC UNIVERSITY SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
*WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED HEREUNDER IS ON AN ��AS IS�� 
*BASIS, AND THE HONG KONG POLYTECHNIC UNIVERSITY HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, 
*ENHANCEMENTS, OR MODIFICATIONS.
*/
//========================================================================================
// 
// File Name    : layer.c
// Description  : 
// Release Date : 22/10/2014
// 
//
// Revision History
//---------------------------------------------------------------------------------------
// Date         Version         Author          Description
//----------------------------------------------------------------------------------------
// 2014          1.0            David Aledo     ANN layer generation (memory allocation
//                                              and initialization)
//
//=======================================================================================

#include "layer.h"
#include <stddef.h> // to define NULL


/* Constructors */

layer() : initialized(false),
DW(NULL), Wprev(NULL), Db(NULL), bprev(NULL), a(NULL), s(NULL)
{}

layer(unsigned int n_in, unsigned int n_n) : NumIn(n_in), NumN(n_n), initialized(true)
{
   /* Dynamic memory */
   b = new int[NumN];
   Db = new float[NumN];
   bprev = new int[NumN];
   a = new int[NumN];
   s = new float[NumN];
   W = new int*[NumN];
   DW = new float*[NumN];
   Wprev = new int*[NumN];
   for(int n=0; n<NumN; n++)
   {
      W[n] = new int[NumIn];
      DW[n] = new float[NumIn];
      Wprev[n] = new int[NumIn];
   }
}


/* Methods */

int initialize(unsigned int n_in, unsigned int n_n)
{
   if(!initialized)
   {
      initialized = true;
      NumIn = n_in;
      NumN = n_n;
      b = new int[NumN];
      Db = new float[NumN];
      bprev = new int[NumN];
      a = new int[NumN];
      s = new float[NumN];
      W = new int*[NumN];
      DW = new float*[NumN];
      Wprev = new int*[NumN];
      for(int n=0; n<NumN; n++)
      {
         W[n] = new int[NumIn];
         DW[n] = new float[NumIn];
         Wprev[n] = new int[NumIn];
      }
      return 0;
   }
   else
      return -1;
}

