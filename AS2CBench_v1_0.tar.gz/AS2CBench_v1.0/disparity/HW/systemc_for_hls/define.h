/*
*This software program and documentation are copyrighted by The Hong Kong Polytechnic University. 
*The software program and documentation are supplied ��as *is��, without any accompanying services 
*from The University. The University does not warrant that the operation of the program will be 
*uninterrupted or error-free.The end-user understands that the program was developed for research 
*purposes and is advised not to rely exclusively on the program for any reason.
*
*IN NO EVENT SHALL THE HONG KONG POLYTECHNIC UNIVERSITY BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT, SPECIAL, 
*INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS 
*DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN AD- VISED OF THE POSSIBILITY OF SUCH DAMAGE. THE HONG 
*KONG POLYTECHNIC UNIVERSITY SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
*WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED HEREUNDER IS ON AN ��AS IS�� 
*BASIS, AND THE HONG KONG POLYTECHNIC UNIVERSITY HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, 
*ENHANCEMENTS, OR MODIFICATIONS.
*/
//============================================================================
// 
// File Name    : define.h
// Description  : Define the parameters
// Release Date : 16/07/2013
// Author       :
//
// Revision History
//---------------------------------------------------------------------------
// Date     Author      Version     Description
//---------------------------------------------------------------------------
// 16/07/13 PolyU           1.0     library, macros and parameters declaration      
//===========================================================================

#ifndef DEFINE_H
#define DEFINE_H
#include <systemc.h>

#define Width_max    1920 //maximum image width

#define HEIGHT          64 //macroblock horizontal size
#define WIDTH           64 //macroblock vertical size
#define FULL            64 // Search range

#define ADJ          128/FULL
#define DIST_ADJUST_LOW     6
#define DIST_ADJUST_HIGH   36

#define MAX_DIFF   128

#define HOFFSET     20
#define WOFFSET     200 


#define INFILENAME           "3D_crysis.bmp"
#define OUTFILENAME          "3D_crysis_out.bmp"
#define OUTFILENAME_GOLDEN   "3D_crysis_out_golden.bmp"
#define DIFFFILENAME         "disparity_diff.txt"

//#define WAVE_DUMP


#endif  // end DEFINE_H
