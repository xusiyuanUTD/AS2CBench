/*
*This software program and documentation are copyrighted by The Hong Kong Polytechnic University. 
*The software program and documentation are supplied ��as *is��, without any accompanying services 
*from The University. The University does not warrant that the operation of the program will be 
*uninterrupted or error-free.The end-user understands that the program was developed for research 
*purposes and is advised not to rely exclusively on the program for any reason.
*
*IN NO EVENT SHALL THE HONG KONG POLYTECHNIC UNIVERSITY BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT, SPECIAL, 
*INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS 
*DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN AD- VISED OF THE POSSIBILITY OF SUCH DAMAGE. THE HONG 
*KONG POLYTECHNIC UNIVERSITY SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
*WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED HEREUNDER IS ON AN ��AS IS�� 
*BASIS, AND THE HONG KONG POLYTECHNIC UNIVERSITY HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, 
*ENHANCEMENTS, OR MODIFICATIONS.
*/
//---------------------------------------------------------------------------
// 
//
// File Name    : disparity_kernel.cpp
// Description  : 3D disparity estimation
// Release Date : 16/07/13
// Author       : 
//
// Revision History
//---------------------------------------------------------------------------
// Date     Author      Version     Description
//---------------------------------------------------------------------------
//16/07/13
//---------------------------------------------------------------------------
#include "disparity.h"


//---------------------------
// Main disparity estimatation function
//    1.- Get the difference between Right and Left pixel and adjust
//    2.- Calculate the sum of absolute differences (SAD)
//    3.- Find min sad for each image window and generate output
//--------------------------


sc_int<32> disparity::MAX(sc_int<32>a, sc_int<32> b){
  return a>b?a:b; 
}

sc_int<32> disparity::MIN(sc_int<32> a, sc_int<32> b){
  return a>b?b:a; 

}


void disparity::run()
{

  // Variables declaration
  sc_uint<10>hsize=0;    
  sc_uint<7> hd=0;        
//  int hbnd;     
  sc_uint<10> wsize=0;    
  sc_uint<7> wd=0;       
//  int wbnd;    
  int sum_all=0;
  unsigned int x=0, y=0;
  unsigned int n=0,m=0,l=0,nn=0;
  sc_uint<16>   height=0;
  sc_uint<16>   width=0;
  sc_uint<8> Right_pixel_Y=0;
  sc_uint<8> Left_pixel_Y=0;
  bool valid_in=false;
  bool input_valid_compare,input_valid_read; 
  bool output_control_compare,output_control_read;
  bool p=false,p1=false;


  // counters initializations
  count_hd = 0;
  count_wd = 0;
  count_delay = 0;
  count_hsize = 0;
  count_wsize = 0;
  count_pixel = 0;
  count_line = 0;
  count_skip_line = 0;
  count_skip_pixel = 0;

  // Arrays can't be mapped to memories if initialization is needed
  for(x = 0;x < MAX_DIFF; x++) {
    tmp_sum[x] = 0;
    final_sum[x] = 0;
    Left_buffer [x]=0; 
  }
 
  for(y = 0; y< FULL; y++) {
     Right_buffer[y]=0;
  }
 
  valid_cycle.write(false);

  wait();


  // --- Main disparity estiation computational loop
  while(1) {

	//valid_cycle.write(true);
  // --- Obtain the basic parameter

// ---Obtain the height and width, execute only once 
/*
  height=Height_Width.read();
  width=Height_Width.read();
*/
//inputs 
//inputs
     while(p==false){

	input_valid_read=input_valid_signal.read();
	if(input_valid_compare!=input_valid_read)
                             {
		//valid_cycle.write(false);	
		n++;
		input_valid_compare=input_valid_read;	
	                  }
		if(n==2)  		//detect that is an pulse 
		{    
			 n=0;	 	 
			 height=  sc_uint<16>(UUT_in.read());
			 p=true;
			 break;
		}	
	wait();
	}
       while(p1==false){

	input_valid_read=input_valid_signal.read();
	if(input_valid_compare!=input_valid_read)
                             {
		//valid_cycle.write(false);		
		n++;
		input_valid_compare=input_valid_read;	
	                  }
		if(n==2)  		//detect that is an pulse 
		{    
			 n=0;	 	 
			 width=sc_uint<16>(UUT_in.read());
 			 p1=true;
if(height==0){
      hsize = 0;    
      hd   = 0;    
   //   hbnd  = 0;    
    }
    else{
unsigned int resu= height;
      if(resu%HEIGHT == 0)
     // if(height%HEIGHT == 0)
	hsize =  height/HEIGHT;
      else
	hsize = (height/HEIGHT)+1;

      if(resu%HEIGHT == 0)
     // if(height%HEIGHT==0)
	hd = HEIGHT;
      else
	hd = HEIGHT-1;
             
    //  hbnd  = ((height - hd*hsize)/2) + (((height - hd*hsize)/2)%2);
    }
    
    if(width==0){
      wsize = 0;     
      wd   = 0;    
     // wbnd = 0;    
    }
    else{
unsigned int resu1= width;
   //   if(width%WIDTH==0)
 if(resu1%WIDTH==0)
	wsize = width/WIDTH;
      else
	wsize = (width/WIDTH)+1; 
 
      wd = WIDTH;
                   
    //  wbnd  = ((width  - wd*wsize)/2) + (((width  - wd*wsize)/2)%2);
    }
			 break;
		}	
	wait();
	}

 

// ---Obtain the height and width, execute only once 
/*
  valid_in=valid_in_signal.read();
  Left_pixel_Y=Pixel_Y.read();
  Right_pixel_Y=Pixel_Y.read();

*/
 
  while(1){

	input_valid_read=input_valid_signal.read();
	if(input_valid_compare!=input_valid_read)
                             {
		valid_cycle.write(false);		
		n++;
		input_valid_compare=input_valid_read;	
	                  }
		if(n==2)  		//detect that is an pulse 
		{    
			 n=0;	 	 
			valid_in=bool(UUT_in.read());
			break;
		}	
	wait();
	}

  while(1){

	input_valid_read=input_valid_signal.read();
	if(input_valid_compare!=input_valid_read)
                             {
		valid_cycle.write(false);		
		n++;
		input_valid_compare=input_valid_read;	
	                  }
		if(n==2)  		//detect that is an pulse 
		{    
			 n=0;	 	 
			Left_pixel_Y=sc_uint<8>(UUT_in.read());
			break;
		}	
	wait();
	}	  

  while(1){

	input_valid_read=input_valid_signal.read();
	if(input_valid_compare!=input_valid_read)
                             {
		valid_cycle.write(false);		
		n++;
		input_valid_compare=input_valid_read;	
	                  }
		if(n==2)  		//detect that is an pulse 
		{    
			 n=0;	 	 
			Right_pixel_Y=sc_uint<8>(UUT_in.read());
			break;
		}	
	wait();
	}
	//valid_in=valid_in_signal.read();



 if(count_hd < hd) {
	//printf("count_hd is %d\n",count_hd); 
    if ( count_hsize <  hsize ) {

	//printf("count_hsize is %d\n",count_hsize); 
	//count_delay = 0;
	//printf("delay is %d\n",count_delay);

	if(valid_in==true || count_wd  < wd){

	//printf("count_wd is %d\n",count_wd);
 	for(x = 1 ;x < FULL; x++) {
	    Right_buffer[x-1] = Right_buffer[x];
	  }
	  Right_buffer[FULL-1] = Right_pixel_Y;
	

	  if(count_delay == 0){
	    for(x = 1 ; x < MAX_DIFF; x++) {
	      Left_buffer[x] = Left_pixel_Y;	
	    }
		
	  }
	  else{

	    for(x = 1 ;x < MAX_DIFF;x++) {
	      Left_buffer[x-1] = Left_buffer[x];
	    }
	    Left_buffer[MAX_DIFF-1] = Left_pixel_Y;    	
		
	  }	
	if( valid_in==true && count_delay < FULL-1) {
	    count_delay++;
	  //  printf("delay is %d\n",count_delay);
	  }
	  else if(count_delay >= FULL-1 || count_pixel >= MAX_DIFF*8) {
	    // Calculate pixel differences
	    bool t = (count_wsize == wsize-1);
            for(x = 0; x < MAX_DIFF; x++) {

              pixel_Ly = Left_buffer[x];
              pixel_Ry = Right_buffer[0];

	      // Compute the absolute value of the Left and Right pixels
	      if(pixel_Ly > pixel_Ry)
		pixel_LR_diff = pixel_Ly-pixel_Ry;
	      else
		pixel_LR_diff = pixel_Ry-pixel_Ly;

	      
	      // Adjust the pixel difference 
              if(pixel_LR_diff< DIST_ADJUST_LOW )
                pixel_LR_diff_adj = pixel_LR_diff;

              else if(DIST_ADJUST_HIGH <= pixel_LR_diff )
                pixel_LR_diff_adj = pixel_LR_diff * 2;

              else
                pixel_LR_diff_adj = pixel_LR_diff;
	      // Sum up the differences
              tmp_sum[x] = tmp_sum[x]+ MIN(127,pixel_LR_diff_adj);
              sum_all = tmp_sum[x]+final_sum[x];

	      if(t) {
		sad[x][count_wd]=sum_all ;	
                tmp_sum[x] = 0;
	      } 
	      else if(count_wsize == 0){
		final_sum[x] = sad[x][count_wd];
	      }
	    }  // end for loop 128
	
            // Update control counters
            count_wsize++;
            count_pixel++;
	   // printf("count_wsize is %d,wsize is %d\n",count_wsize , wsize);
            if(count_wsize == wsize) {
              count_wd ++;
              count_wsize = 0;
            }
	}// else if(count_delay >= FULL-1 || count_pixel >= MAX_DIFF*8)

	} // while count_wd || while valid_in

	else{ //  count_wd || while valid_in

  		count_line ++;
        	count_wd = 0;
        	count_pixel = 0;
        	count_delay = 0;
		count_hsize++;
		}

	   }//hsize_cnt < hsize.read()

	else //hsize_cnt > hsize.read()
       {
	// Clean up sad memory
        //count_delay=0;

	count_hsize=0;
     //   level = FULL; 
	 for(x = 0; x<64 ; x++) {
  
	for(y = 0; y < MAX_DIFF; y++) {
          sad_single[y]=sad[y][x];
        }
      
	Lsad = sad_single[FULL];
        level = FULL; 
        for(y = 1; y< FULL; y++) {
          if(sad_single[FULL-y] < Lsad) {
            Lsad = sad_single[FULL-y];
            level = 64-y;
          }
         if(sad_single[FULL+y] < Lsad) {
            Lsad = sad_single[FULL+y];
            level = FULL+y;
          }
        }
      if(sad_single[0] < Lsad) {
          level = 0;
        }
        minD = level - FULL;
	//printf("minD is %d\n",minD);
        // n_num= ((n-2-hbnd)/hsize);
         out [count_hd][x] = (MAX(0,MIN(255,minD* ADJ + 128)))& 0xFF;

        // valid_out.write(true);
       //   depth_out.write(out [count_hd][x]);
      } // for(x = 0; x<64 ; x++)
	count_hd++;
	count_delay=0;
       	while(count_delay < FULL){

	    for(x = 0; x< MAX_DIFF; x++) {
	      sad[x][count_delay]=0;  
	    } 

	    count_delay++;
          }
	count_delay = 0;
	 }// else hsize_cnt > hsize.read()	
	} //if(count_hd < hd) 
   else
{
//outputs   
    output_valid_signal.write(true); 
    valid_cycle.write(true);

     while(1){ //second while
 	while(1){ //third while

	output_control_read=output_control_signal.read(); 
	if(output_control_compare!=output_control_read) 
                             {		 
		n++; 
		output_control_compare=output_control_read;	 
	                  } 
		if(n==2)  		//detect that is an pulse  
		{     
		n=0;	 	  
		// UUT_out.write(sc_uint<8>(out[l][m])); 
		output_valid_signal.write(false); 
		UUT_out.write(out[l][m]); 
		m++;  
		break;
		}
				 
		wait();
		}//third while 

		if(m==64) 
		{ 
 			m=0; 
			l++;
		} 
		if(l==64) 
		{ 
 			l=0; 
			break;	 
		} 
		output_valid_signal.write(true); 
	
wait();
}// second while
} //else
valid_cycle.write(true);

wait();

} //while (1) first while
}



