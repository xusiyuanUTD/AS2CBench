/*
*This software program and documentation are copyrighted by The Hong Kong Polytechnic University. 
*The software program and documentation are supplied ��as *is��, without any accompanying services 
*from The University. The University does not warrant that the operation of the program will be 
*uninterrupted or error-free.The end-user understands that the program was developed for research 
*purposes and is advised not to rely exclusively on the program for any reason.
*
*IN NO EVENT SHALL THE HONG KONG POLYTECHNIC UNIVERSITY BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT, SPECIAL, 
*INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS 
*DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN AD- VISED OF THE POSSIBILITY OF SUCH DAMAGE. THE HONG 
*KONG POLYTECHNIC UNIVERSITY SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
*WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED HEREUNDER IS ON AN ��AS IS�� 
*BASIS, AND THE HONG KONG POLYTECHNIC UNIVERSITY HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, 
*ENHANCEMENTS, OR MODIFICATIONS.
*/
//==========================================================================-
// 
// File Name    : disparity.h
// Description  : Disparity estimator module declaration
// Release Date : 16/07/13
// Author       : 
//
// Revision History
//---------------------------------------------------------------------------
// Date     Version    Author       Description
//---------------------------------------------------------------------------
//16/07/13      1.0                 Main image disparity computation
//===========================================================================
#ifndef DISPARITY_H
#define DISPARITY_H
#include "define.h"

SC_MODULE (disparity) {

  // Inputs
  sc_in<bool>         clk;
  sc_in<bool>         rst;
/*
  sc_in<sc_uint<16> > Height_Width;
  sc_in <bool > input_valid_signal_HW; 

  sc_in<sc_uint<8> >  Pixel_Y;
  sc_in <bool > input_valid_signal_Y; 

  sc_in<bool>         valid_in_signal;

  // Outputs
  sc_out<bool>        valid_out;
  sc_out<bool>        valid_cycle;
  sc_in <bool > output_control_signal; 
  sc_out<sc_uint<8> > depth_out;
*/
   //inputs 
  sc_in <sc_uint <32> > UUT_in; //HW Pixe_Y
//  sc_in<bool> valid_in_signal;
  sc_in <bool > input_valid_signal; 
  sc_in <bool > output_control_signal; 
  //outputs 
  sc_out<bool>        valid_cycle;
  sc_out<sc_uint<32> > UUT_out; //depth_out
  sc_out  <bool > output_valid_signal; 

 
  // Internal Variables
  sc_uint<8>            Right_buffer[FULL]/* Cyber array =REG*/;
  sc_uint<8>          Left_buffer [MAX_DIFF]/* Cyber array = REG*/;
  sc_int<20>           sad[MAX_DIFF][FULL]/* Cyber array=RAM, expand_dim=2,  array_hazard = IGNORE */;  // sum of absolute differences

  sc_uint<20>        tmp_sum[MAX_DIFF]/* Cyber array = REG*/;
  sc_uint<20>          final_sum[MAX_DIFF]/* Cyber array =REG*/;

   sc_uint<8>   pixel_Ly,pixel_Ry;  
  sc_int<9>   pixel_LR_diff;
   sc_int<20>   pixel_LR_diff_adj;

   // counters declarations -Declared as integers. HLS tool should optimize their bw
    int count_skip_line;
   int count_skip_pixel ;
    int count_hd;
    int count_wd;
    int count_delay;
   int count_hsize;
   int count_wsize;
   int count_pixel;
   int count_line;

//  sc_signal<sc_uint<1> > HSynch_pulse;
//  sc_signal<sc_uint<1> > HSynch_d1;
  sc_int<20> sad_single[MAX_DIFF]/* Cyber array = REG*/;

  int         level, tlevel;
  sc_int<20>    Lsad;

  int         minD;
//  sc_uint<8>    out[64][64]/* Cyber array=RAM, expand_dim=2,  array_hazard = IGNORE */;
 sc_uint<32>    out[64][64]/* Cyber array=RAM, expand_dim=2,  array_hazard = IGNORE */;

  /* M */
sc_int<32>MAX(sc_int<32> x, sc_int<32>y);
sc_int<32> MIN(sc_int<32> x, sc_int<32> y);

  /* R */
  void run();


  SC_CTOR (disparity){
    SC_CTHREAD(run,clk.pos());
    reset_signal_is(rst,false);
    }

  ~disparity(){}

};
#endif  // DISPARITY_H
