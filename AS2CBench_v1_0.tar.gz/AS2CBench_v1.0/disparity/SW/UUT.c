//========================================================================================
// 
// File Name    : UUT.c
// Description  : Main testbench file
//                Benjamin Carrion Schafer, Xu Siyuan
// 
//        
//=======================================================================================
#include "timer.h"
#include "define.h"
#include <stdio.h>
#include <unistd.h>
#include "hwlib.h"
#include "socal/socal.h"
#include "socal/hps.h"
#include "socal/alt_gpio.h"
#include <malloc.h>
#include "stdlib.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <sys/mman.h>
#include "hps_0.h"
#include <stdbool.h>
//#include "timer.h"

#define HW_REGS_BASE ( ALT_STM_OFST )
#define HW_REGS_SPAN ( 0x04000000 )
#define HW_REGS_MASK ( HW_REGS_SPAN - 1 )

// Internal Variables
  unsigned int          Right_buffer[FULL];
  unsigned int          Left_buffer [MAX_DIFF];
  unsigned int           sad[MAX_DIFF][FULL];  // sum of absolute differences
  unsigned int         tmp_sum[MAX_DIFF];
  unsigned int          final_sum[MAX_DIFF];
  unsigned int  pixel_Ly,pixel_Ry;  
  unsigned int  pixel_LR_diff;
  unsigned int  pixel_LR_diff_adj;
  unsigned int   sad_single[MAX_DIFF];
  int         level, tlevel;
  unsigned int   Lsad;
  int         minD;
  unsigned int   out[64][64];

   // counters declarations -Declared as integers. HLS tool should optimize their bw
  int count_skip_line;
  int count_skip_pixel ;
  int count_hd;
  int count_wd;
  int count_delay;
  int count_hsize;
  int count_wsize;
  int count_pixel;
  int count_line;
  bool valid_in;


 // Variables declaration
  int hsize;    
  int hd;        
  int hbnd;     
  int wsize;    
  int wd;       
  int wbnd;    
  int n_num;
 // int height;
 // int width;
  int sum_all;
  //int x, y;

 // Coefficients converted to integers (ref.:http://en.wikipedia.org/wiki/YUV)
  int rgb2yuv_coeff[3][3] = {{299, 587, 114},
			     {-147, -289, 436},
			     {615, -515, -100}};


 int rgb2yuv_offset[3] = {18, 132, 132};
 int Left_pixel_R;
 int Left_pixel_G;
 int Left_pixel_B;

 int Right_pixel_R;
 int Right_pixel_G;
 int Right_pixel_B;

int Right_pixel_Y;
int Left_pixel_Y;

  /* C */
  void compare_results();

  /* I */
  void initialize();

  /* R */
  void recv();

  /* S */
  void send();
 volatile unsigned long *h2p_lw_valid_out_addr;
 volatile unsigned long *h2p_lw_UUT_addr;
 volatile unsigned long *h2p_lw_valid_in_addr;


//File pointers (bmp) input, outputs and difference
  FILE *in_file, *out_file, *compare_file, *diff_file;

  char BmpHeader1[18];
  char BmpHeader2[28];

  int frame, x, y,n,m;
  unsigned int height, width, plusbytes;

  // Pointers to bmp images loaded/generated
  unsigned char **inbmp;
  unsigned char **inbmpLeft;
  unsigned char **inbmpRight;
  unsigned char **outbmp;
 // unsigned char **comparebmp;
 // unsigned char  inbmp[height][width*3];
//  unsigned char  inbmpLeft[height][width*3];
//  unsigned char  inbmpRight[height][width*6+plusbytes];
 // unsigned char  outbmp[HEIGHT][WIDTH];
  unsigned char  comparebmp[HEIGHT][WIDTH*3];
  //For receiver
  bool          VSynch_single; 
  bool          HSynch_single;
  unsigned int   yi;
  unsigned int   out_x, out_y;



//
// Read input image
//

/*
** RGB to YUV conversion
*/

void RGBtoYUV()
{

    Left_pixel_Y= (int)(( rgb2yuv_coeff[0][0]*(int)(Left_pixel_B) 
			+ rgb2yuv_coeff[0][1]*(int)(Left_pixel_G)
			+ rgb2yuv_coeff[0][2]*(int)(Left_pixel_R))/1024 
		        + rgb2yuv_offset[0]);

    Right_pixel_Y = (int)(( rgb2yuv_coeff[0][0]*(int)(Right_pixel_B)
			+ rgb2yuv_coeff[0][1]*(int)(Right_pixel_G)
			+ rgb2yuv_coeff[0][2]*(int)(Right_pixel_R))/1024
		        + rgb2yuv_offset[0]);

}



//-------------------------
// Send input stimuli
//------------------------
void  send(){

  // Variables declarations
  int xlimit=0;
  int ylimit=0,read;
  int test,zz;
/*
  valid_in.write(false);

 alt_write_word(h2p_lw_Right_pixel_R_addr,0);
 alt_write_word(h2p_lw_Right_pixel_G_addr,0);
 alt_write_word(h2p_lw_Right_pixel_B_addr,0);
 alt_write_word(h2p_lw_Left_pixel_R_addr,0);
 alt_write_word(h2p_lw_Left_pixel_G_addr,0);
 alt_write_word(h2p_lw_Left_pixel_B_addr,0);

 alt_write_word(h2p_lw_VSynch_addr,0);
 alt_write_word(h2p_lw_HSynch_addr,0);
 alt_write_word(h2p_lw_Height_addr,0);
 alt_write_word(h2p_lw_Width_addr,0);

 //int finish_read = 0;
 alt_write_word(h2p_lw_valid_in_addr,0);
*/
//  initialize();

  frame=0;
  x=0;
  y=0;

  // Open bmp file with stereoscopic image 
  in_file = fopen(INFILENAME,"rb");

  if (in_file){
    fread(&BmpHeader1, 18, sizeof(unsigned char), in_file);  
    fread(&width,        4, sizeof(unsigned char), in_file); 
    fread(&height,       4, sizeof(unsigned char), in_file); 
    fread(&BmpHeader2, 28, sizeof(unsigned char), in_file); 
    plusbytes = (4 - (width * 3) % 4) % 4;
    width  = width>>1;
  }else{
    //cout<<"Could not read bmp file "<<  INFILENAME <<endl;
     printf("Could not read bmp file  INFILENAME\n");
    //sc_stop();
  }

//printf("height is %d\n",height); //1080
//printf("width is %d\n",width); //960
//printf("plusbytes is %d\n",plusbytes); //0

  // Allocate memory for the image
//  inbmp       = new unsigned char *[height];
//  inbmpLeft   = new unsigned char *[height];
 // inbmpRight  = new unsigned char *[height];
	inbmp  = (unsigned char**)malloc(sizeof(unsigned char*)*height);
	inbmpLeft  = (unsigned char**)malloc(sizeof(unsigned char*)*height);
	inbmpRight  = (unsigned char**)malloc(sizeof(unsigned char*)*height);
    //verify memory allocation

  for(y=0;y<height;y++)
    {

    //  inbmpLeft[y]  = new unsigned char [width*3]; //960*3
    //  inbmpRight[y] = new unsigned char [width*3]; //960*3
    //  inbmp[y]      = new unsigned char [width*6+plusbytes];

	
	inbmpLeft[y]   = (unsigned char*)malloc(sizeof(unsigned char)*width*3);
	inbmpRight[y]   = (unsigned char*)malloc(sizeof(unsigned char)*width*3);
	inbmp[y]   = (unsigned char*)malloc(sizeof(unsigned char)*(width*6+plusbytes)*2); //5760
    }
    //printf("inbmp is %d\n",width*6+plusbytes);
 // outbmp = new unsigned char *[HEIGHT];
 outbmp  = (unsigned char**)malloc(sizeof(unsigned char*)*HEIGHT);


  for(y=0;y<HEIGHT;y++){
   // outbmp[y]    = new unsigned char [WIDTH];
	outbmp[y]  = (unsigned char*)malloc(sizeof(unsigned char)*WIDTH);
    for(x=0;x<WIDTH;x++){
      outbmp[y][x]= 0;
	//printf("outbmp is %d\n",outbmp[y][x]);
    }
  }
//printf("size of inbmp is %d\n",sizeof(inbmp));
  // Load image into memory
  for(y=height-1;y>=0;y--){
    fread(inbmp[y], 1, width*6+plusbytes, in_file);
    
    for(x=0;x<width;x++){
      inbmpLeft[y][x*3+2]=inbmp[y][x*3+2];
      inbmpLeft[y][x*3+1]=inbmp[y][x*3+1];
      inbmpLeft[y][x*3+0]=inbmp[y][x*3+0];
      
      inbmpRight[y][x*3+2]=inbmp[y][(width+x)*3+2];
      inbmpRight[y][x*3+1]=inbmp[y][(width+x)*3+1];
      inbmpRight[y][x*3+0]=inbmp[y][(width+x)*3+0];
	
	//printf("inbmp is %d\n",(width+x)*3+2);
    }
	//printf("inbmp[%d][%d] is %d\n",y,(width+x)*3+2,inbmp[y][(width+x)*3+2] );
	//printf("y is %d\n",y);
  }

    fclose(in_file);


      printf("Finish Initialization \n");
  // -- Main loop for sending data to disparity estimator

  //wait();
 // Variables declaration
 // int height = Height.read();
   // Initialization
 alt_write_word(h2p_lw_UUT_addr,height);
 alt_write_word(h2p_lw_UUT_addr,width);

 if(height==0){
      hsize = 0;    
      hd   = 0;    
      hbnd  = 0;    
    }
    else{
      if(height%HEIGHT == 0)
	hsize =  height/HEIGHT;
      else
	hsize = (height/HEIGHT)+1;

      if(height%HEIGHT==0)
	hd = HEIGHT;
      else
	hd = HEIGHT-1;
             
      hbnd  = ((height - hd*hsize)/2) + (((height - hd*hsize)/2)%2);
    }
    
    if(width==0){
      wsize = 0;     
      wd   = 0;    
      wbnd = 0;    
    }
    else{
      if(width%WIDTH==0)
	wsize = width/WIDTH;
      else
	wsize = (width/WIDTH)+1; 
 
      wd = WIDTH;
                   
      wbnd  = ((width  - wd*wsize)/2) + (((width  - wd*wsize)/2)%2);
    }


   //alt_write_word(h2p_lw_Height_addr,height);
  // alt_write_word(h2p_lw_Width_addr,width);  

 //UUT Initialization
 // counters initializations
  count_hd = 0;
  count_wd = 0;
  count_delay = 0;
  count_hsize = 0;
  count_wsize = 0;
  count_pixel = 0;
  count_line = 0;


  // Arrays can't be mapped to memories if initialization is needed
  for(x = 0;x < MAX_DIFF; x++) {
    tmp_sum[x] = 0;
    final_sum[x] = 0;
    Left_buffer [x]=0; 
  }
 
  for(y = 0; y< FULL; y++) {
     Right_buffer[y]=0;
  }

  count_delay=0;
       	while(count_delay < FULL){

	    for(x = 0; x< MAX_DIFF; x++) {
	      sad[x][count_delay]=0;  
	    } 

	    count_delay++;
          }	
	count_delay = 0;

//////////////////

    //  printf("hsize is %d\n",hsize);
     // printf("wsize is %d\n",wsize);
    //  printf("hd is %d\n",hd);
    //  printf("wd is %d\n",wd);
    //  printf("hbnd is %d\n",hbnd);
    //  printf("wbnd is %d\n",wbnd);
//printf("valid_cycle is %d\n",alt_read_word(h2p_lw_valid_in_addr));
     for(n=0;n<(height+HOFFSET);n++){
      
       if((n<5+hbnd+1)||(n>height+5)){
	       }
       else{     
  	//printf("n is %d\n",n);
	 for(m=0;m<(width+WOFFSET);m++){
	
	   // Ignore edges
	   if((m<100)||(m>=(width+(WOFFSET/2)))){ 
       	   //valid_in=0;
 	   alt_write_word(h2p_lw_UUT_addr,0);
	   Left_pixel_R=0;
 	   Left_pixel_G=0;
 	   Left_pixel_B=0;
 	   Right_pixel_R=0;
 	   Right_pixel_G=0;
 	   Right_pixel_B=0;
	   } 
	   else{
	     // Set control signals to start writting data
	     if(n-(HOFFSET/4) >= height)
	       ylimit = height-1;
	     else
	       ylimit = n - (HOFFSET/4);
	    
	     if(m - (WOFFSET/2)>= width )
	       xlimit = width -1;
	       else
		 xlimit = m- (WOFFSET/2);
	   //valid_in=1;
 	   alt_write_word(h2p_lw_UUT_addr,1);
	   Left_pixel_R=inbmpLeft[ylimit][xlimit*3+2];
 	   Left_pixel_G=inbmpLeft[ylimit][xlimit*3+1];
 	   Left_pixel_B=inbmpLeft[ylimit][xlimit*3+0];
 	   Right_pixel_R=inbmpRight[ylimit][xlimit*3+2];
 	   Right_pixel_G=inbmpRight[ylimit][xlimit*3+1];
 	   Right_pixel_B=inbmpRight[ylimit][xlimit*3+0];
	  
	}
        RGBtoYUV();

	//printf("R_pixel_Y is %d\n",Right_pixel_Y);
	//printf("L_pixel_Y is %d\n",Left_pixel_Y);
     alt_write_word(h2p_lw_UUT_addr, Left_pixel_Y);
 	//printf("valid_cycle is %d\n",alt_read_word(h2p_lw_valid_in_addr));
     alt_write_word(h2p_lw_UUT_addr, Right_pixel_Y);
	//printf("valid_out is %d\n",alt_read_word(h2p_lw_valid_out_addr));

	while(!alt_read_word(h2p_lw_valid_in_addr));
	//printf("cycle\n");
		        }//m for_loop
       }     //else
     }   //n for_loop

	//printf("Finished Senting Data\n");
	while(1){

	read=alt_read_word(h2p_lw_valid_out_addr);

	if(read==1)
	{

	for(y=0;y<hd;y++){
	for(x=0;x<64;x++){
	alt_write_word(h2p_lw_valid_out_addr,true);
	while(!(alt_read_word(h2p_lw_valid_out_addr)));
	outbmp[y][x]=alt_read_word(h2p_lw_UUT_addr);
		}};
	break;
	}


}
    printf("Start Comparing\n");
     compare_results();

}




//----------------------------
// Compare results function
//----------------------------
void  compare_results(){
    
  // Variables
  int errors=0;

  // Create bmp file with results
  out_file     = fopen(OUTFILENAME,"wb");
 
    //------------------------
    //Load the golden output
    //------------------------
    compare_file = fopen(OUTFILENAME_GOLDEN,"rb");
    if (compare_file){
      fread(&BmpHeader1, 18, sizeof(unsigned char), compare_file);     
      fread(&width,        4, sizeof(unsigned char), compare_file);  
      fread(&height,       4, sizeof(unsigned char), compare_file);      
      fread(&BmpHeader2, 28, sizeof(unsigned char), compare_file);      
      plusbytes = (4 - (width * 3) % 4) % 4;
      if((height!=HEIGHT)||(width!=WIDTH)){
	printf("The size of compare bmp is error\n");
      //  cout<<"The size of compare bmp is error"<<endl;
      //  sc_stop();
	exit (-1);
      }

    }else{
      //cout<<"Coult not open file " << OUTFILENAME_GOLDEN << endl;
      printf("Coult not open file  OUTFILENAME_GOLDEN\n");
      //sc_stop();
      exit (-1);
    }
    
  //  comparebmp  = new unsigned char *[HEIGHT];
//  comparebmp = (unsigned char*)malloc(HEIGHT);

  //  for(y=0;y<HEIGHT;y++)
   //   comparebmp[y]    = new unsigned char [WIDTH*3];
 // comparebmp[y] = (unsigned char)malloc(WIDTH*3);
    for(y=HEIGHT-1;y>=0;y--)
      fread(comparebmp[y], 1, WIDTH*3+plusbytes, compare_file);

 if (out_file){
    width  = WIDTH;
    height = HEIGHT;
    
    fwrite(&BmpHeader1, 18, sizeof(unsigned char), out_file);
    fwrite(&width,        4, sizeof(unsigned char), out_file);
    fwrite(&height,       4, sizeof(unsigned char), out_file);
    fwrite(&BmpHeader2, 28, sizeof(unsigned char), out_file);
  }
  else{
    printf("Could not open bmp file OUTFILENAME\n");

  //  sc_stop();
    exit (-1);
  }
  for(y=HEIGHT-1;y>=0;y--){
    for(x=0;x<WIDTH;x++){
      fwrite(&outbmp[y][x], 1, 1, out_file);
      fwrite(&outbmp[y][x], 1, 1, out_file);
      fwrite(&outbmp[y][x], 1, 1, out_file);
      if(x==(WIDTH-1)&&(plusbytes!=0))
	fwrite(0, 1, plusbytes, out_file);
    }
  }
    
    // Write comparison result
   diff_file    = fopen(DIFFFILENAME,"wb");
    for(y=0;y<HEIGHT;y++)
      for(x=0;x<WIDTH;x++)
        if((int)outbmp[y][x]!=(int)comparebmp[y][x*3]){
        //  cout<<"Output missmatch (y,x)=("<<y<<","<<x<<"): output= "<<(int)outbmp[y][x]<<" , golden= "<<(int)comparebmp[y][x*3]<<endl;
          fprintf(diff_file,"Output missmatch (y,x)=(%d,%d): output= %d , golden= %d;\n",y,x,outbmp[y][x],comparebmp[y][x*3]);
	  errors ++;
        }


    if(errors == 0)
     printf("Finished simulation SUCCESSFULLY \n" );
    else
    printf("MISSMATCHES between Golden and Simulation \n" );

    fclose(out_file);
    fclose(compare_file);
    fclose(diff_file);

}



//--------------------------
// Main function
//--------------------------


int main(int argc, char **argv)
{


	void *virtual_base;
	int fd;
	GET_TIME_INIT(2);
   
	// map the address space for the LED registers into user space so we can interact with them.
	// we'll actually map in the entire CSR span of the HPS since we want to access various registers within that span
	if( ( fd = open( "/dev/mem", ( O_RDWR | O_SYNC ) ) ) == -1 ) {
		printf( "ERROR: could not open \"/dev/mem\"...\n" );
		return( 1 );
	}
	virtual_base = mmap( NULL, HW_REGS_SPAN, ( PROT_READ | PROT_WRITE ), MAP_SHARED, fd, HW_REGS_BASE );	
	if( virtual_base == MAP_FAILED ) {
		printf( "ERROR: mmap() failed...\n" );
		close( fd );
		return(1);
	}

  	h2p_lw_valid_out_addr=virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + OUTPUT_VALID_BASE) & ( unsigned long)( HW_REGS_MASK ) );
 	h2p_lw_UUT_addr=virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + UUT_IO_BASE) & ( unsigned long)( HW_REGS_MASK ) );
  	h2p_lw_valid_in_addr=virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + INPUT_VALID_BASE) & ( unsigned long)( HW_REGS_MASK ) );
	GET_TIME_VAL(0);
		send();
	GET_TIME_VAL(1);
	printf("\n\nRunning time %10.4f\n",( TIME_VAL_TO_MS(1) - TIME_VAL_TO_MS(0))/1000);
	if( munmap( virtual_base, HW_REGS_SPAN ) != 0 ) {
		printf( "ERROR: munmap() failed...\n" );
		close( fd );
		return( 1 );

	}
	close( fd ); 
	return 0;
}
