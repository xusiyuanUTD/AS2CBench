/*
*This software program and documentation are copyrighted by The Hong Kong Polytechnic University. 
*The software program and documentation are supplied ��as *is��, without any accompanying services 
*from The University. The University does not warrant that the operation of the program will be 
*uninterrupted or error-free.The end-user understands that the program was developed for research 
*purposes and is advised not to rely exclusively on the program for any reason.
*
*IN NO EVENT SHALL THE HONG KONG POLYTECHNIC UNIVERSITY BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT, SPECIAL, 
*INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS 
*DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN AD- VISED OF THE POSSIBILITY OF SUCH DAMAGE. THE HONG 
*KONG POLYTECHNIC UNIVERSITY SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
*WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED HEREUNDER IS ON AN ��AS IS�� 
*BASIS, AND THE HONG KONG POLYTECHNIC UNIVERSITY HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, 
*ENHANCEMENTS, OR MODIFICATIONS.
*/

//========================================================================================
// 
// File Name    : sobel.h
// Description  : Sobel filter implemenetation
// Release Date : 23/07/2013
// Author       : PolyU DARC Lab
//                Benjamin Carrion Schafer, Anushree Mahapatra,Xu Siyuan
//
// Revision History
//---------------------------------------------------------------------------------------
// Date        Version    Author            Description
//---------------------------------------------------------------------------------------
//23/07/2013      1.0     PolyU DARC Lab     main sobel definition header            
//=======================================================================================
#include "define.h"
#include "sobel.h"

void sobel::sobel_main(void)
{

  sc_uint<8> input_row_read[3];
  sc_uint<8> output_row_write;
 int x,y;
 bool input_valid_compare,input_valid_read;
 bool output_control_compare,output_control_read;


  wait();

while(1){
//inputs
     while(1){

	input_valid_read=input_valid_signal.read();
	if(input_valid_compare!=input_valid_read)
                             {
		output_valid_signal.write(false); 		
		x++;
		input_valid_compare=input_valid_read;	
	                  }
		if(x==2)  		//detect that is an pulse 
		{    
			 x=0;	 	 
			 input_row_read[y]=UUT_in.read();
			 y++; 
		}	

		if(y==3)
		{
 			y=0;
			break;	
		}
	wait();
	}

	
    

	

       // Perform the filtering of a 3x3 pixel image segment
     output_row_write =  sobel_filter(input_row_read);
	 
	 
      // Writting filtered output back 
      //UUT_out.write(output_row_write);
     // output_valid_signal.write(true); 
//outputs  
     output_valid_signal.write(true); 
     while(1){

	output_control_read=output_control_signal.read();

	if(output_control_compare!=output_control_read)
                             {		
		x++;
		output_control_compare=output_control_read;	
	                  }
		if(x==2)  		//detect that is an pulse 
		{    
			 x=0;	 	 
			 UUT_out.write(output_row_write);
			 y++; 
		}	

		if(y==1)
		{
 			y=0;
			break;	
		}
	wait();
	}

      wait();

  }// end of while
}


//
// Sobel filter function
//
sc_uint<8>  sobel::sobel_filter(sc_uint<8> *input_row_r)
{

  unsigned int X, Y;
  unsigned char orow;
  int sumX, sumY;
  int SUM, rowOffset, colOffset;


  
  char Gx[3][3] ={{-1 ,-2 ,-1},
		  { 0, 0, 0},
		  { +1, 2, +1}};  


  char Gy[3][3] ={{1, -2, 1},
		  {0, 0, 0},
		  {-1, 0, 1}};


  /* Shifting 3x3 line buffer by one row  */

   for(Y=2;Y>0;Y--){
     for(X=0;X< 3;X++){
       line_buffer[Y][X]=line_buffer[Y-1][X];
     }
   }	
	
   // Reading new data into the line buffer
   for(X=0; X<SIZE_BUFFER; X++)
     line_buffer[0][X] = input_row_r[X];

 

   Y=1;
   X=1;
   sumX = 0;
   sumY = 0;

   // Convolution starts here
   //-------X GRADIENT APPROXIMATION------
   //-------Y GRADIENT APPROXIMATION------   
   for(rowOffset = -1; rowOffset <= 1; rowOffset++){
     for(colOffset = -1; colOffset <=1; colOffset++){
       sumX = sumX + line_buffer[Y -rowOffset][X+colOffset] * Gx[1+rowOffset][1+colOffset];
       sumY = sumY + line_buffer[Y -rowOffset][X+colOffset] * Gy[1+rowOffset][1+colOffset];
   	}
    }


      if(sumX > 255)    sumX = 255;
      else if(sumX < 0) sumX = 0;

      if(sumY > 255)    sumY = 255;
      else if(sumY < 0) sumY = 0;


      SUM = sumX + sumY;
      
      if(SUM > 255)    SUM = 255;
         else if(SUM < 0) SUM = 0;     
   
      orow = 255  - (unsigned char)(SUM);
      return ((sc_uint<8>) orow);

}
 


