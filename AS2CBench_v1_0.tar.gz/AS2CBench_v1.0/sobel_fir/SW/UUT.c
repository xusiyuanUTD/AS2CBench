/*
*This software program and documentation are copyrighted by The Hong Kong Polytechnic University. 
*The software program and documentation are supplied ��as *is��, without any accompanying services 
*from The University. The University does not warrant that the operation of the program will be 
*uninterrupted or error-free.The end-user understands that the program was developed for research 
*purposes and is advised not to rely exclusively on the program for any reason.
*
*IN NO EVENT SHALL THE HONG KONG POLYTECHNIC UNIVERSITY BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT, SPECIAL, 
*INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS 
*DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN AD- VISED OF THE POSSIBILITY OF SUCH DAMAGE. THE HONG 
*KONG POLYTECHNIC UNIVERSITY SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
*WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED HEREUNDER IS ON AN ��AS IS�� 
*BASIS, AND THE HONG KONG POLYTECHNIC UNIVERSITY HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, 
*ENHANCEMENTS, OR MODIFICATIONS.
*/
//========================================================================================
// 
// File Name    : UUT.c
// Description  : Main testbench file
//                Benjamin Carrion Schafer, Xu Siyuan
// 
//        
//=======================================================================================

#include "define.h"
#include <stdio.h>
#include <unistd.h>
#include "hwlib.h"
#include "socal/socal.h"
#include "socal/hps.h"
#include "socal/alt_gpio.h"
#include <malloc.h>
#include "stdlib.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <sys/mman.h>
#include "hps_0.h"
#include <stdbool.h>
#include <pthread.h>

#define HW_REGS_BASE ( ALT_STM_OFST )
#define HW_REGS_SPAN ( 0x04000000 )
#define HW_REGS_MASK ( HW_REGS_SPAN - 1 )

 volatile unsigned long *h2p_lw_UUT_addr;
 volatile unsigned long *h2p_lw_outvalid_addr;
 volatile unsigned long *h2p_lw_UUT1_addr;
 volatile unsigned long *h2p_lw_outvalid1_addr;

   //variables
  unsigned char *bitmapData;
  unsigned char  *bitmapFinalImage;
  FILE *ifptr, *ofptr, *diffptr;
  BITMAPINFOHEADER bitmapInfoHeader;
  BITMAPFILEHEADER bitmapFileHeader; //our bitmap file header
  unsigned char biColourPalette[1024];

  //FIR File pointers
  FILE * in_filter_file, *in_coeff_file, *out_filter_golden_file, *out_filter_file_read;
  FILE  *out_filter_file, *diff_file;
//---------------------------------
// FIR Compare results function
//--------------------------------
void FIR_compare_results(void){

  int outfilter, outfilter_golden, line=1, errors=0;

  // Close file where outputs are stored
  fclose(out_filter_file);

  // Open results file
  out_filter_file = fopen (OUTFILENAME, "rt");

  if(!out_filter_file){
   printf(" Could not open  OUTFILENAME " ) ;
    exit (-1);
  }

    //
    //Load the golden output from file

    out_filter_golden_file = fopen (OUTFILENAME_GOLDEN, "rt");
    if(!out_filter_golden_file){
   printf("    Could not open OUTFILENAME_GOLDEN  ");
      exit (-1);
     }

    //
    // comparison result with golden output
    //

    diff_file = fopen (DIFFFILENAME_FIR, "w");
    if(!diff_file){
	printf("  Could not open  DIFFFILENAME_FIR  " );
	 exit (-1);
       }

    //      while(out_filter_golden_file.eof()){
    while(fscanf(out_filter_golden_file, "%d", &outfilter_golden) != EOF){
      fscanf(out_filter_file,"%d", &outfilter);
     


	   if(outfilter != outfilter_golden){

	     fprintf(diff_file,"\nOutput missmatch[line:%d] Golden: %d -- Output: %d",line, outfilter_golden, outfilter);
	     
	     errors++;
	   }

          line ++;

    }

    if(errors == 0)
     printf("Finished FIR simulation SUCCESSFULLY \n" );
    else
    printf("FIR / MISSMATCHES between Golden and Simulation \n" );


    fclose(out_filter_file);
    fclose(diff_file);
    fclose(out_filter_golden_file);



}


//--------------------------
// FIR Send data thread
//--------------------------
void FIR_send(void){

  // Variables declaration
  int i=0;
  unsigned int coeff_read, in_filter_read;
  unsigned int filter_out_write=0;
  	int read;



  // out_filter_file.open (OUTFILENAME);
  out_filter_file = fopen (OUTFILENAME, "wt");
  //Reset routine
  in_filter_file = fopen(INFILTERFILENAME, "rt");
  in_coeff_file = fopen(INCOEFFFILENAME, "rt");
 

  if(!in_filter_file){
   printf(" Could not open  INFILTERFILENAME   " );
    exit (-1);
  }


  if(!in_coeff_file){
    printf( " Could not open  INCOEFFFILENAME   ");
    exit (-1);
  }

  if(!out_filter_file){
    printf("  Could not open  OUTFILENAME   " );
    exit (-1);
  }

  for(i=0; i < FILTER_TAPS; i++){
    if(fscanf(in_coeff_file, "%u", &coeff_read) == EOF) break;
    alt_write_word(h2p_lw_UUT1_addr,coeff_read);

  }
  

  	
	
	i=0;

    	 while(fscanf(in_filter_file,"%u", &in_filter_read) != EOF){

	  	alt_write_word(h2p_lw_UUT1_addr,in_filter_read);
		//printf("in_filter_read is %d\n",in_filter_read);
		i++;

		

	if(i==FILTER_TAPS)
				{
			i=0;
	

	while(1)	{
  	 		 read=alt_read_word(h2p_lw_outvalid1_addr);
		
			if(read==1)
			{
			 alt_write_word(h2p_lw_outvalid1_addr,true);
   			 filter_out_write = alt_read_word(h2p_lw_UUT1_addr);
			 fprintf(out_filter_file,"%d\n",filter_out_write);
			// printf("output is %d\n",filter_out_write);
			 break;
		
			}
	
			}
		

				}


	
    }


    fclose(in_coeff_file);
    fclose(in_filter_file);


  printf("Starting FIR comparing results \n " );
 
    FIR_compare_results();

}
//--------------------------
//  Bitmap loading function
//--------------------------

unsigned char *load_bitmapfile(const char *image)
{
 
  unsigned char *bitmapImage;
 // int l;

 // Open bmp file to be filtered
  ifptr = fopen(image,"rb");
  if(!ifptr){
       exit(-1);
  }


  if(ifptr == NULL){
    exit (-1);
  }

 fread(&bitmapFileHeader, sizeof(BITMAPFILEHEADER),1,ifptr);



 if (bitmapFileHeader.bfType !=0x4D42)
    {
        fclose(ifptr);
	
    }

 // Read the bitmap info header
 fread(&bitmapInfoHeader, sizeof(BITMAPINFOHEADER),1,ifptr);

 // Read colour palette
 fread(&biColourPalette,1,bitmapInfoHeader.biClrUsed*4,ifptr);



    //move file point to the begging of bitmap data
    fseek(ifptr, bitmapFileHeader.bfOffBits, SEEK_SET);

    //allocate enough memory for the bitmap image data
    bitmapImage = (unsigned char*)malloc(bitmapInfoHeader.biSizeImage);

    //verify memory allocation
    if (!bitmapImage)
      {
	free(bitmapImage);
	return NULL;
	}

    //read in the bitmap image data
    fread(bitmapImage,1, bitmapInfoHeader.biSizeImage,ifptr);

    if (bitmapImage == NULL)
      {
		return NULL;
	}


    fclose(ifptr);
    return bitmapImage;
}

//--------------------------
//  compare_results
//-------------------------

void compare_results(){


  // Variables declaration
  int i,j, line =0, errors=0;

  // free memory of original image which contains un-filterd image.
  if(bitmapData != NULL)
    free(bitmapData);

  // Read Golden output image data
  bitmapData =  load_bitmapfile(IMAGE_GOLDEN);

  //Dump the comparison result
    diffptr = fopen (DIFFFILENAME, "w");
    if(!diffptr){
           exit (-1);
    }
    

    // Main data comparison loop
     for(i=0;i<ROWS;i++){
       for(j=1;j<COLS;j++){

	// bitmapData[(i*ROWS)+j];
	  


	   if( bitmapFinalImage[(i*ROWS)+j] !=  bitmapData[(i*ROWS)+j]){
	     fprintf(diffptr,"\nOutput missmatch[line:%d] Golden: %x -- Output: %x",line,  bitmapData[(i*ROWS)+j],  bitmapFinalImage[(i*ROWS)+j]);	     
	     errors++;
	   }

          line ++;

	 }
     }

    if(errors == 0)
     printf( "Finished simulation SUCCESSFULLY  \n" );
    else
     printf(" MISSMATCHES between Golden and Simulation  \n" );


    fclose(diffptr);

}
/*
 ** Create new BMP file for filter results
*/


void image_write(void){

  // Variables declaration
  int i,j,bytesperline,n;
  int l,k;
  unsigned char  *tk;




 k=sizeof(BITMAPFILEHEADER);
 l=sizeof(BITMAPINFOHEADER);


 bytesperline = bitmapInfoHeader.biWidth * BYTES_PER_PIXEL; // multiply by 3 only for 24 bit images

 
 if( bytesperline & 0x0003)
   {  bytesperline |= 0x0003;
     ++bytesperline;}



 tk = (unsigned char  *)calloc(1,bytesperline);
 bitmapFileHeader.bfSize= bitmapInfoHeader.biSize + (long)bytesperline* bitmapInfoHeader.biHeight;

 bitmapFileHeader.bfOffBits = k+l+ 4* bitmapInfoHeader.biClrUsed;
 bitmapFileHeader.bfSize = k+l+bitmapInfoHeader.biSizeImage;

 
 n=0;



 if(ofptr!=NULL){
   fwrite(&bitmapFileHeader,1,sizeof(BITMAPFILEHEADER),ofptr);
   fwrite(&bitmapInfoHeader,1,sizeof(BITMAPINFOHEADER),ofptr);
   fwrite(biColourPalette,bitmapInfoHeader.biClrUsed*4,1,ofptr);



   for(i=(bitmapInfoHeader.biHeight-1); i>=0; i--){  
       for(j=0;j<=(bytesperline)-1;j++){
	   tk[j] = bitmapFinalImage[n++];
	   }

       fwrite(tk,1,bytesperline,ofptr);
   }
   
      
 }
 else{
   }


 fclose(ofptr);
 free(tk);

}

//--------------------------
// Send data thread
//-------------------------

void send(void){

	


  // Variables declration
  static int i,j,k;
   int input_row_write[3];
 // variablesd declaration
 
 
	int read;
 double elapsed;
 time_t end,start=time(NULL);
	
	

  // Initialization 
  bitmapData =  load_bitmapfile(IMAGE_IN);
  

  i=0;
  j=0;





  //open file for writing
  ofptr=fopen(IMAGE_OUT,"wb");

  bitmapFinalImage = (unsigned char *)malloc(bitmapInfoHeader.biSizeImage);
  if (!bitmapFinalImage)
    {
      free(bitmapFinalImage);
       }



    // Send Image data to sobel filter
     for(i=0;i<ROWS;i++){
         for(j=1;j<COLS;j++){
	   for(k=j-1;k<=j+1;k++){
	
	     // Send triplets at a time
	     if(k==j-1){
	       input_row_write[0] = bitmapData[(i*ROWS)+k];
	    
		alt_write_word(h2p_lw_UUT_addr,input_row_write[0]);
		
	     }
	     else if(k==j){
	       input_row_write[1] = bitmapData[(i*ROWS)+k];
	    
		alt_write_word(h2p_lw_UUT_addr,input_row_write[1]);
		
	     }
	     else{
	       input_row_write[2]= bitmapData[(i*ROWS)+k];
	  
		alt_write_word(h2p_lw_UUT_addr,input_row_write[2]);
		
	     }
	   }
	while(1){

	read=alt_read_word(h2p_lw_outvalid_addr);

	if(read==1)
	{
	alt_write_word(h2p_lw_outvalid_addr,true);
	bitmapFinalImage[(i*ROWS)+j]=alt_read_word(h2p_lw_UUT_addr);
	break;
	}


}



	 }

 }
printf("Starting sobel comparing results \n " );
compare_results();
 image_write(); 

 	end = time(NULL);
    	elapsed = difftime(end, start);
	printf("\n\n SOBEL Running time %10.4f\n", elapsed);  
  
}












//--------------------------
// Main function
//--------------------------


int main(int argc, char **argv)
{


	void *virtual_base;
	int fd;
	pthread_t id;
	int ret;
   	double elapsed;
	
	// map the address space for the LED registers into user space so we can interact with them.
	// we'll actually map in the entire CSR span of the HPS since we want to access various registers within that span
	if( ( fd = open( "/dev/mem", ( O_RDWR | O_SYNC ) ) ) == -1 ) {
		printf( "ERROR: could not open \"/dev/mem\"...\n" );
		return( 1 );
	}
	virtual_base = mmap( NULL, HW_REGS_SPAN, ( PROT_READ | PROT_WRITE ), MAP_SHARED, fd, HW_REGS_BASE );	
	if( virtual_base == MAP_FAILED ) {
		printf( "ERROR: mmap() failed...\n" );
		close( fd );
		return(1);
	}
	h2p_lw_UUT_addr=virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + UUT_IO_BASE) & ( unsigned long)( HW_REGS_MASK ) );
	h2p_lw_outvalid_addr=virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + OUTPUT_VALID_BASE ) & ( unsigned long)( HW_REGS_MASK ) );
	h2p_lw_UUT1_addr=virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + UUT_IO1_BASE) & ( unsigned long)( HW_REGS_MASK ) );
	h2p_lw_outvalid1_addr=virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + OUTPUT_VALID1_BASE ) & ( unsigned long)( HW_REGS_MASK ) );
	
	printf("Starting sobel simulation \n " );
	ret=pthread_create(&id,NULL,(void *)send,NULL);
	if(ret!=0){
		printf("Creat pthread error!\n");
		exit(1);	
	}
	printf("Starting FIR simulation \n " );
	time_t end,start=time(NULL);
	FIR_send();
	end = time(NULL);
    	elapsed = difftime(end, start);
	printf("\n\n FIR Running time %10.4f\n", elapsed);

	pthread_join(id,NULL);

	if( munmap( virtual_base, HW_REGS_SPAN ) != 0 ) {
		printf( "ERROR: munmap() failed...\n" );
		close( fd );
		return( 1 );

	}
	close( fd );
	return 0;
}
