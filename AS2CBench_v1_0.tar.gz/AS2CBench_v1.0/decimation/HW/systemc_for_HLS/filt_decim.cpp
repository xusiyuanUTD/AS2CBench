/*
*This software program and documentation are copyrighted by The Hong Kong Polytechnic University. 
*The software program and documentation are supplied ��as *is��, without any accompanying services 
*from The University. The University does not warrant that the operation of the program will be 
*uninterrupted or error-free.The end-user understands that the program was developed for research 
*purposes and is advised not to rely exclusively on the program for any reason.
*
*IN NO EVENT SHALL THE HONG KONG POLYTECHNIC UNIVERSITY BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT, SPECIAL, 
*INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS 
*DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN AD- VISED OF THE POSSIBILITY OF SUCH DAMAGE. THE HONG 
*KONG POLYTECHNIC UNIVERSITY SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
*WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED HEREUNDER IS ON AN ��AS IS�� 
*BASIS, AND THE HONG KONG POLYTECHNIC UNIVERSITY HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, 
*ENHANCEMENTS, OR MODIFICATIONS.
*/
//========================================================================================
// 
// File Name    : decfilt.cpp
// Description  : Main 5 stages decimation filter functionality
// Release Date : 29/07/2013
// Author       : PolyU DARC Lab
//                Benjamin Carrion Schafer, Anushree Mahapatra,Xu Siyuan
//
// Revision History
//---------------------------------------------------------------------------------------
// Date        Author   Version     Description
//----------------------------------------------------------------------------------------
//29/07/2013   PolyU        1.0     Decimation filter 
//=======================================================================================

#include "filt_decim.h"

void decfilt::run() 
{

 

 const sc_fixed<17,2,SC_RND,SC_SAT> incoef1_var[TAPS_STAGE1]={0.42613453,
							-0.3761934,
							0.58146343,
							-0.9781433} ;
 const  sc_fixed<17,2,SC_RND,SC_SAT> incoef2_var[TAPS_STAGE2]={0.50624113,
							0.7465933,
							0.1158962,
							-0.542682} ;
 const  sc_fixed<17,2,SC_RND,SC_SAT> incoef3_var[TAPS_STAGE3]={0.3448823,
							        0.2772235,
							0.8998734,
							0.4820888};
  const sc_fixed<17,2,SC_RND,SC_SAT> incoef4_var[TAPS_STAGE4]={-0.254842,
							0.1636232,
							0.1010024,
							0.37212005,
							-0.1467290,
							-0.958045};
  const sc_fixed<17,2,SC_RND,SC_SAT> incoef5_var[TAPS_STAGE5]={0.3085756,
							0.11119545,
							-0.561322,
							0.14281342,
							0.30441124,
							0.9697556,
							-0.1298584,
							0.2757340,
							0.50624113,
							0.7465933,
							0.1158962,
							-0.542682};
 unsigned int z=0,y=0;
 bool input_valid_compare,input_valid_read;
 bool output_control_compare,output_control_read;

 stage_counter_1 = 0;
 stage_counter_2 = 0;
 stage_counter_3 = 0;
 stage_counter_4 = 0;
 stage_counter_5 = 0;

 unsigned int x=0;
  bool stage_control_1 = false;
  bool stage_control_2 = false;
  bool stage_control_3 = false;
  bool stage_control_4 = false;
  bool stage_control_5 = false;


 wait();
 
 // Main stage filter body
 
 while( true )
 {

 
  // Read filter in_stage data 
 // in_stage_1 = indata.read();
//inputs

     while(1){

	input_valid_read=input_valid_signal.read();
	if(input_valid_compare!=input_valid_read)
                             {
		output_valid_signal.write(false); 		
		z++;
		input_valid_compare=input_valid_read;	
	                  }
		if(z==2)  		//detect that is an pulse 
		{    
			 z=0;	 	 
			in_stage_1=(UUT_in.read()/1000000.0);
			break;
		}	

		
	wait();
	}


  //================================
  // Stage 1
  //================================

     
  // Shift data and store new data
  for( x = BUFFER_SIZE_STAGE1-1; x > 0; x--) {
   bufferline_1[x] = bufferline_1[x-1];
  }
  bufferline_1[0] = in_stage_1;

  SoP1 = 0;
  stage_control_1 = false;

  for (x = 0; x < TAPS_STAGE1; x++) {
    if( x == TAPS_STAGE1-1 )
      buffer_1 = 0;
    else 
      buffer_1 = bufferline_1[ BUFFER_SIZE_STAGE1-1 - x];
  

   SoP1 = SoP1 + (bufferline_1[x]+buffer_1 )*incoef1_var[x];
  }
  
  stage_1 = sc_fixed<19, 2, SC_RND, SC_SAT>(SoP1);

  
  if(stage_counter_1 == 2) {
    stage_counter_1 = 0;
    stage_control_1 = true;
  }
  else {
    stage_counter_1++;
  }

  //================================
  // Stage 2
  //================================
  if (stage_control_1)
    in_stage_2 = stage_1;

  for(x =  BUFFER_SIZE_STAGE2-1; x > 0; x--) {
    bufferline_2[x] = bufferline_2[x-1];
  }
  bufferline_2[0] = in_stage_2;

  SoP2 = 0;
  stage_control_2 = false;


  if(stage_control_1){

    for (x = 0; x < TAPS_STAGE2; x++) {
      if( x == TAPS_STAGE2-1 )
	buffer_2 = 0;
      else
	buffer_2 = bufferline_2[ BUFFER_SIZE_STAGE2-1 - x];
      
      SoP2 = SoP2 + (bufferline_2[x]+buffer_2 )*incoef2_var[x];
    }


  stage_2 = sc_fixed<19, 2, SC_RND, SC_SAT>(SoP2);

  if(stage_counter_2 == 2){
    stage_counter_2 = 0;
    stage_control_2 = true;
  }
  else {
   stage_counter_2++;
  }
}
  
  //================================
  // Stage 3
  //================================
  if (stage_control_2)
      in_stage_3 = stage_2;
	  
  for(x = BUFFER_SIZE_STAGE3-1; x > 0; x--) {
    bufferline_3[x] = bufferline_3[x-1];
  }
  bufferline_3[0] = in_stage_3;

  SoP3 = 0;
  stage_control_3 = false;

  if(stage_control_2){

    for (x = 0; x < TAPS_STAGE3; x++) {
      if( x == TAPS_STAGE3-1 )
	buffer_3 = 0;
      else 
	buffer_3 = bufferline_3[BUFFER_SIZE_STAGE3-1 - x];
      SoP3 = SoP3 + (bufferline_3[x]+buffer_3)*incoef3_var[x];
    }
  


  stage_3 = sc_fixed<19, 2, SC_RND, SC_SAT>(SoP3);

  if(stage_counter_3 == 1) { 
   	stage_counter_3 = 0;
   	stage_control_3 = true;
  } else {
   	stage_counter_3++;
  }
}

  //================================
  // Stage 4
  //================================
  if (stage_control_3)
   in_stage_4 = stage_3;
 
  for(x = BUFFER_SIZE_STAGE4-1; x > 0; x--) {
   bufferline_4[x] = bufferline_4[x-1];
  }
  bufferline_4[0] = in_stage_4;

  SoP4 = 0;
  stage_control_4= false;

if(stage_control_3){

  for (x = 0; x < TAPS_STAGE4; x++) {
   if( x == TAPS_STAGE4-1 )
     buffer_4 = 0;
   else
     buffer_4 = bufferline_4[BUFFER_SIZE_STAGE4-1 - x];

   SoP4 = SoP4 + (bufferline_4[x]+buffer_4)*incoef4_var[x];
  }
  
  stage_4 = sc_fixed<19, 2, SC_RND, SC_SAT>(SoP4);
 
  if(stage_counter_4 == 1) {
    stage_counter_4 = 0;
    stage_control_4 = true;
  }
  else {
   stage_counter_4++;
  }
}
 
  //================================
  // Stage 5
  //================================
  
  if (stage_control_4)
   in_stage_5 = stage_4;
 
  for(x = BUFFER_SIZE_STAGE5-1; x > 0; x--) {
   bufferline_5[x] = bufferline_5[x-1];
  }
  bufferline_5[0] = in_stage_5;

  SoP5 = 0;
  stage_control_5 = false;


if(stage_control_4){
  for (x = 0; x < TAPS_STAGE5; x++) {
    SoP5 = SoP5 + (bufferline_5[x]+bufferline_5[ BUFFER_SIZE_STAGE5-1 - x])*incoef5_var[x];
  }


  stage_5 = sc_fixed<19, 2, SC_RND, SC_SAT>(SoP5);

  if(stage_counter_5 == 1) {
    stage_counter_5 = 0;
    stage_control_5 = true;
  }
  else {
    stage_counter_5++;
  }
}


// Write decimation filter output
 if ( stage_control_5){
  output_valid_signal.write(true); 
     while(1){
	output_control_read=output_control_signal.read();

	if(output_control_compare!=output_control_read)
                             {		
		z++;
		output_control_compare=output_control_read;	
	                  }
		if(z==2)  		//detect that is an pulse 
		{    
			 z=0;	 	 
			 UUT_out.write((sc_int<32> (stage_5*1000000)));
			break;
		}	


	wait();
	}

  output_valid_signal.write(false);
  stage_control_5 = false;
}
else
{
  output_valid_signal.write(true); 
     while(1){
	output_control_read=output_control_signal.read();

	if(output_control_compare!=output_control_read)
                             {		
		z++;
		output_control_compare=output_control_read;	
	                  }
		if(z==2)  		//detect that is an pulse 
		{    
			 z=0;	 	 
			// UUT_out.write((sc_int<32> (2)));
			break;
		}	


	wait();
	}

  output_valid_signal.write(false);
}

 wait(); 
 }

}
