/*
*This software program and documentation are copyrighted by The Hong Kong Polytechnic University. 
*The software program and documentation are supplied ��as *is��, without any accompanying services 
*from The University. The University does not warrant that the operation of the program will be 
*uninterrupted or error-free.The end-user understands that the program was developed for research 
*purposes and is advised not to rely exclusively on the program for any reason.
*
*IN NO EVENT SHALL THE HONG KONG POLYTECHNIC UNIVERSITY BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT, SPECIAL, 
*INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS 
*DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN AD- VISED OF THE POSSIBILITY OF SUCH DAMAGE. THE HONG 
*KONG POLYTECHNIC UNIVERSITY SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
*WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED HEREUNDER IS ON AN ��AS IS�� 
*BASIS, AND THE HONG KONG POLYTECHNIC UNIVERSITY HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, 
*ENHANCEMENTS, OR MODIFICATIONS.
*/
//========================================================================================
// 
// File Name    : filter_decim.h
// Description  : Main 5 stages decimation filter component declaration
// Release Date : 31/07/2013
// Author       : PolyU DARC Lab
//                Benjamin Carrion Schafer, Anushree Mahapatra ,Xu Siyuan
// 
//
// Revision History
//---------------------------------------------------------------------------------------
// Date       Version   Author      Description
//----------------------------------------------------------------------------------------
//31/07/2013      1.0    PolyU      Decimation filter module declaration
//=======================================================================================

#ifndef DECFILT_H_
#define DECFILT_H_
#define SC_INCLUDE_FX 
#include "define.h"


SC_MODULE(decfilt)
 {


public:
   
   // Inputs
   
   sc_in_clk clk;   
   sc_in<bool> rst;
 sc_in <  sc_int<32>  > UUT_in;
  sc_in <bool > input_valid_signal;
  sc_in <bool > output_control_signal;
  //outputs
//  sc_out< sc_fixed<16,1,SC_RND,SC_SAT> > UUT_out;
  sc_out< sc_int<32> > UUT_out;
  sc_out  <bool > output_valid_signal;
/*
   sc_in<bool> load_coeff;    
   sc_in < sc_fixed<19,2,SC_RND,SC_SAT> > indata;

   sc_in< sc_fixed<17,2,SC_RND,SC_SAT> > incoef1[TAPS_STAGE1] ;
   sc_in< sc_fixed<17,2,SC_RND,SC_SAT> > incoef2[TAPS_STAGE2] ;
   sc_in< sc_fixed<17,2,SC_RND,SC_SAT> > incoef3[TAPS_STAGE3] ;
   sc_in< sc_fixed<17,2,SC_RND,SC_SAT> > incoef4[TAPS_STAGE4] ;
   sc_in< sc_fixed<17,2,SC_RND,SC_SAT> > incoef5[TAPS_STAGE5] ;

   // Output   
   sc_out < sc_fixed<19, 2, SC_RND, SC_SAT> > odata;
*/

   // Variables
   int stage_counter_1;   // decimation stages counter. HLS toold should 
   int stage_counter_2;   // adust bitwidth automatically
   int stage_counter_3;
   int stage_counter_4;
   int stage_counter_5;
   
   sc_fixed<19,2,SC_RND,SC_SAT> bufferline_1[7];
   sc_fixed<19,2,SC_RND,SC_SAT> bufferline_2[7];
   sc_fixed<19,2,SC_RND,SC_SAT> bufferline_3[7];
   sc_fixed<19,2,SC_RND,SC_SAT> bufferline_4[11];
   sc_fixed<19,2,SC_RND,SC_SAT> bufferline_5[24];

 // signals for STAGE 1
  sc_fixed<19,2,SC_TRN,SC_SAT> in_stage_1;
  sc_fixed<19,2,SC_TRN,SC_SAT> buffer_1;
  sc_fixed<19, 2, SC_RND, SC_SAT> stage_1;

  // signals for STAGE 2
  sc_fixed<19,2,SC_RND,SC_SAT> in_stage_2;
  sc_fixed<19,2,SC_RND,SC_SAT> buffer_2;
  sc_fixed<19, 2, SC_RND, SC_SAT> stage_2;


  // signals for STAGE 3
  sc_fixed<19,2,SC_RND,SC_SAT> in_stage_3;
  sc_fixed<19,2,SC_RND,SC_SAT> buffer_3;
  sc_fixed<19, 2, SC_RND, SC_SAT> stage_3;


  // signals for STAGE 4
  sc_fixed<19,2,SC_RND,SC_SAT> in_stage_4;
  sc_fixed<19,2,SC_RND,SC_SAT> buffer_4;
  sc_fixed<19, 2, SC_RND, SC_SAT> stage_4;


  // signals for STAGE 5
  sc_fixed<19,2,SC_RND,SC_SAT> in_stage_5;
  sc_fixed<19, 2, SC_RND, SC_SAT> stage_5;


  sc_fixed<36,6,SC_TRN,SC_WRAP> SoP1;
   sc_fixed<36,6,SC_TRN,SC_WRAP> SoP2;
   sc_fixed<36,6,SC_TRN,SC_WRAP> SoP3;
   sc_fixed<36,6,SC_TRN,SC_WRAP> SoP4;
   sc_fixed<36,6,SC_TRN,SC_WRAP> SoP5;
   // Functions declarations
   /*  R  */
   void run ( void );


 SC_CTOR (decfilt) {
   SC_CTHREAD (run, clk.pos()); 
   reset_signal_is(rst, false);
 };
 

   ~decfilt() {};


};

#endif   // END DECFILT_
