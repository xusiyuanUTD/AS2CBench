/*
*This software program and documentation are copyrighted by The Hong Kong Polytechnic University. 
*The software program and documentation are supplied ��as *is��, without any accompanying services 
*from The University. The University does not warrant that the operation of the program will be 
*uninterrupted or error-free.The end-user understands that the program was developed for research 
*purposes and is advised not to rely exclusively on the program for any reason.
*
*IN NO EVENT SHALL THE HONG KONG POLYTECHNIC UNIVERSITY BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT, SPECIAL, 
*INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS 
*DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN AD- VISED OF THE POSSIBILITY OF SUCH DAMAGE. THE HONG 
*KONG POLYTECHNIC UNIVERSITY SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
*WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED HEREUNDER IS ON AN ��AS IS�� 
*BASIS, AND THE HONG KONG POLYTECHNIC UNIVERSITY HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, 
*ENHANCEMENTS, OR MODIFICATIONS.
*/
//========================================================================================
// 
//
// File Name    : define.h
// Description  : Main definition header for decimation filter
// Author       : PolyU DARC Lab
//                Benjamin Carrion Schafer, Xu Siyuan
//
//=======================================================================================

#ifndef DEFINE_H
#define DEFINE_H

//#include "systemc.h"

//#include <iostream>
#include "stdio.h"

#define TAPS_STAGE1 4
#define TAPS_STAGE2 4
#define TAPS_STAGE3 4
#define TAPS_STAGE4 6
#define TAPS_STAGE5 12
#define STAGES 5

#define BUFFER_SIZE_STAGE1 7
#define BUFFER_SIZE_STAGE2 7
#define BUFFER_SIZE_STAGE3 7
#define BUFFER_SIZE_STAGE4 11
#define BUFFER_SIZE_STAGE5 24



#define IN_DATA_FILENAME          "decim_data.txt"
#define IN_COEFF_FILENAME         "decim_coeff.txt"

#define OUTFILENAME_GOLDEN   "decim_output_golden.txt"

#define OUTFILENAME         "decim_output.txt"
#define DIFFFILENAME        "decim_diff.txt"


//#define WAVE_DUMP          // set do dump waveform or set as compile option -DWAVE_DUMP

#endif  // DEFINE_H

