/*
*This software program and documentation are copyrighted by The Hong Kong Polytechnic University. 
*The software program and documentation are supplied ��as *is��, without any accompanying services 
*from The University. The University does not warrant that the operation of the program will be 
*uninterrupted or error-free.The end-user understands that the program was developed for research 
*purposes and is advised not to rely exclusively on the program for any reason.
*
*IN NO EVENT SHALL THE HONG KONG POLYTECHNIC UNIVERSITY BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT, SPECIAL, 
*INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS 
*DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN AD- VISED OF THE POSSIBILITY OF SUCH DAMAGE. THE HONG 
*KONG POLYTECHNIC UNIVERSITY SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
*WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED HEREUNDER IS ON AN ��AS IS�� 
*BASIS, AND THE HONG KONG POLYTECHNIC UNIVERSITY HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, 
*ENHANCEMENTS, OR MODIFICATIONS.
*/
//========================================================================================
// 
// File Name    : UUT.c
// Description  : Main testbench file
// Author       : PolyU DARC Lab
//                Benjamin Carrion Schafer,Xu Siyuan
// 
//    
//=======================================================================================

#include "define.h"
#include <stdio.h>
#include <unistd.h>
#include "hwlib.h"
#include "socal/socal.h"
#include "socal/hps.h"
#include "socal/alt_gpio.h"
#include <malloc.h>
#include "stdlib.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <sys/mman.h>
#include "hps_0.h"
#include <stdbool.h>

#define HW_REGS_BASE ( ALT_STM_OFST )
#define HW_REGS_SPAN ( 0x04000000 )
#define HW_REGS_MASK ( HW_REGS_SPAN - 1 )

 volatile unsigned long *h2p_lw_UUT_addr;
 volatile unsigned long *h2p_lw_outvalid_addr;

  //File pointers
  FILE * in_filter_file, *in_coeff_file, *out_filter_golden_file, *out_filter_file_read;
  FILE  *out_filter_file, *diff_file;

//---------------------------------
// Compare results function
//--------------------------------
void compare_results(void){

  int outfilter, outfilter_golden, line=1, errors=0;

  // Close file where outputs are stored
  fclose(out_filter_file);

  // Open results file
  out_filter_file = fopen (OUTFILENAME, "rt");

  if(!out_filter_file){
   printf(" Could not open  OUTFILENAME " ) ;
    exit (-1);
  }

    //
    //Load the golden output from file

    out_filter_golden_file = fopen (OUTFILENAME_GOLDEN, "rt");
    if(!out_filter_golden_file){
   printf("    Could not open OUTFILENAME_GOLDEN  ");
      exit (-1);
     }

    //
    // comparison result with golden output
    //

    diff_file = fopen (DIFFFILENAME, "w");
    if(!diff_file){
	printf("  Could not open  DIFFFILENAME  " );
	 exit (-1);
       }

    //      while(out_filter_golden_file.eof()){
    while(fscanf(out_filter_golden_file, "%d", &outfilter_golden) != EOF){
      fscanf(out_filter_file,"%d", &outfilter);
     


	   if(outfilter != outfilter_golden){

	     fprintf(diff_file,"\nOutput missmatch[line:%d] Golden: %d -- Output: %d",line, outfilter_golden, outfilter);
	     
	     errors++;
	   }

          line ++;

    }

    if(errors == 0)
     printf("Finished simulation SUCCESSFULLY \n" );
    else
    printf("MISSMATCHES between Golden and Simulation \n" );


    fclose(out_filter_file);
    fclose(diff_file);
    fclose(out_filter_golden_file);



}


//--------------------------
// Send data thread
//--------------------------
void send(void){

  // Variables declaration
  int i=0;
  unsigned int coeff_read, in_filter_read;
  unsigned int filter_out_write=0;
  	int read;



  // out_filter_file.open (OUTFILENAME);
  out_filter_file = fopen (OUTFILENAME, "wt");
  //Reset routine
  in_filter_file = fopen(INFILTERFILENAME, "rt");
  in_coeff_file = fopen(INCOEFFFILENAME, "rt");
 

  if(!in_filter_file){
   printf(" Could not open  INFILTERFILENAME   " );
    exit (-1);
  }


  if(!in_coeff_file){
    printf( " Could not open  INCOEFFFILENAME   ");
    exit (-1);
  }

  if(!out_filter_file){
    printf("  Could not open  OUTFILENAME   " );
    exit (-1);
  }

  for(i=0; i < FILTER_TAPS; i++){
    if(fscanf(in_coeff_file, "%u", &coeff_read) == EOF) break;
    alt_write_word(h2p_lw_UUT_addr,coeff_read);

  }
  

  	
	
	i=0;

    	 while(fscanf(in_filter_file,"%u", &in_filter_read) != EOF){

	  	alt_write_word(h2p_lw_UUT_addr,in_filter_read);
		//printf("in_filter_read is %d\n",in_filter_read);
		i++;

		

	if(i==FILTER_TAPS)
				{
			i=0;
	

	while(1)	{
  	 		 read=alt_read_word(h2p_lw_outvalid_addr);
		
			if(read==1)
			{
			 alt_write_word(h2p_lw_outvalid_addr,true);
   			 filter_out_write = alt_read_word(h2p_lw_UUT_addr);
			 fprintf(out_filter_file,"%d\n",filter_out_write);
			// printf("output is %d\n",filter_out_write);
			 break;
		
			}
	
			}
		

				}


	
    }


    fclose(in_coeff_file);
    fclose(in_filter_file);


  printf("Starting comparing results \n " );
 
    compare_results();

}


//--------------------------
// Main function
//--------------------------


int main(int argc, char **argv)
{


	void *virtual_base;
	int fd;
	double elapsed;
   
	// map the address space for the LED registers into user space so we can interact with them.
	// we'll actually map in the entire CSR span of the HPS since we want to access various registers within that span
	if( ( fd = open( "/dev/mem", ( O_RDWR | O_SYNC ) ) ) == -1 ) {
		printf( "ERROR: could not open \"/dev/mem\"...\n" );
		return( 1 );
	}
	virtual_base = mmap( NULL, HW_REGS_SPAN, ( PROT_READ | PROT_WRITE ), MAP_SHARED, fd, HW_REGS_BASE );	
	if( virtual_base == MAP_FAILED ) {
		printf( "ERROR: mmap() failed...\n" );
		close( fd );
		return(1);
	}
	h2p_lw_UUT_addr=virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + UUT_IO_BASE) & ( unsigned long)( HW_REGS_MASK ) );
	h2p_lw_outvalid_addr=virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + OUTPUT_VALID_BASE ) & ( unsigned long)( HW_REGS_MASK ) );
	  time_t end,start=time(NULL);
		send();
  	end = time(NULL);
    	elapsed = difftime(end, start);
  	printf("\n\nRunning time %10.4f\n", elapsed);
	if( munmap( virtual_base, HW_REGS_SPAN ) != 0 ) {
		printf( "ERROR: munmap() failed...\n" );
		close( fd );
		return( 1 );

	}
	close( fd );
	return 0;
}
