/*
*This software program and documentation are copyrighted by The Hong Kong Polytechnic University. 
*The software program and documentation are supplied ��as *is��, without any accompanying services 
*from The University. The University does not warrant that the operation of the program will be 
*uninterrupted or error-free.The end-user understands that the program was developed for research 
*purposes and is advised not to rely exclusively on the program for any reason.
*
*IN NO EVENT SHALL THE HONG KONG POLYTECHNIC UNIVERSITY BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT, SPECIAL, 
*INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS 
*DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN AD- VISED OF THE POSSIBILITY OF SUCH DAMAGE. THE HONG 
*KONG POLYTECHNIC UNIVERSITY SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
*WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED HEREUNDER IS ON AN ��AS IS�� 
*BASIS, AND THE HONG KONG POLYTECHNIC UNIVERSITY HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, 
*ENHANCEMENTS, OR MODIFICATIONS.
*/
//========================================================================================
// 
// File Name    : fir.cpp
// Description  : FIR filter
// Release Date : 14/02/2013
// Author       : PolyU DARC Lab
//                Benjamin Carrion Schafer, Anushree Mahapatra ,Xu Siyuan
// 
// Revision History
//---------------------------------------------------------------------------------------
// Date         Version    Author      Description
//---------------------------------------------------------------------------------------
//14/02/2013      1.0       PolyU     FIR filter main description
//=======================================================================================

#include "fir.h"


//  Main thread  
void fir::fir_main ( void ) {

   // Variables declaration
    sc_uint<8> filter_output_function ; 
    sc_uint<8> in_data_read[9];
    sc_uint<16> coeff_read[9] ;
    int i,n,m;
 int x,y;
 bool input_valid_compare,input_valid_read;
 bool output_control_compare,output_control_read;
    bool p=false;
    // Reset state - should be executable in 1 clock cycle
     
     wait();  
 

   // Main thread	
   while (1) {
	

//inputs
     while(p==false){

	input_valid_read=input_valid_signal.read();
	if(input_valid_compare!=input_valid_read)
                             {
		output_valid_signal.write(false); 		
		x++;
		input_valid_compare=input_valid_read;	
	                  }
		if(x==2)  		//detect that is an pulse 
		{    
			 x=0;	 	 
			 coeff_read[y]=UUT_in.read();
			 y++; 
		}	

		if(y==FILTER_TAPS)
		{
 			y=0;
			p=true;
			break;	
		}
	wait();
	}

//inputs
     while(1){

	input_valid_read=input_valid_signal.read();
	if(input_valid_compare!=input_valid_read)
                             {
		output_valid_signal.write(false); 		
		x++;
		input_valid_compare=input_valid_read;	
	                  }
		if(x==2)  		//detect that is an pulse 
		{    
			 x=0;	 	 
			in_data_read[y]=UUT_in.read();
			 y++; 
		}	

		if(y==FILTER_TAPS)
		{
 			y=0;
			break;	
		}
	wait();
	}


	 // Filter function
   	 filter_output_function = filter(in_data_read, coeff_read);

	


//outputs  
     output_valid_signal.write(true); 
     while(1){

	output_control_read=output_control_signal.read();

	if(output_control_compare!=output_control_read)
                             {		
		x++;
		output_control_compare=output_control_read;	
	                  }
		if(x==2)  		//detect that is an pulse 
		{    
			 x=0;	 	 
			 UUT_out.write(filter_output_function);
			 y++; 
		}	

		if(y==1)
		{
 			y=0;
			break;	
		}
	wait();
	}
     output_valid_signal.write(false); 
	 wait();
}


}

// Filter function
sc_uint<8> fir::filter(
    sc_uint<8>  *ary, 
    sc_uint<16>  *coeff)
{
    int sop=0;
    sc_uint <8> filter_result ;
    int i ;


    // Sum of product (SOP) generation 
    for(i=0;i<FILTER_TAPS-1;i++){
        sop += ary[i] * coeff[i] ;
    } 

    // Sign adjustment and rounding to sc_unit <8>)
    if ( sop < 0 ){
        sop = 0 ;
    }

    filter_result = sc_uint<8>(sop);

    return filter_result;
}


