/*
*This software program and documentation are copyrighted by The Hong Kong Polytechnic University. 
*The software program and documentation are supplied ��as *is��, without any accompanying services 
*from The University. The University does not warrant that the operation of the program will be 
*uninterrupted or error-free.The end-user understands that the program was developed for research 
*purposes and is advised not to rely exclusively on the program for any reason.
*
*IN NO EVENT SHALL THE HONG KONG POLYTECHNIC UNIVERSITY BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT, SPECIAL, 
*INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS 
*DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN AD- VISED OF THE POSSIBILITY OF SUCH DAMAGE. THE HONG 
*KONG POLYTECHNIC UNIVERSITY SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
*WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED HEREUNDER IS ON AN ��AS IS�� 
*BASIS, AND THE HONG KONG POLYTECHNIC UNIVERSITY HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, 
*ENHANCEMENTS, OR MODIFICATIONS.
*/
//========================================================================================
// 
// File Name    : fir.h
// Description  : FIR filter module declaration
// Release Date : 14/02/2013
// Author       : PolyU DARC Lab
//                Benjamin Carrion Schafer, Anushree Mahapatra ,Xu Siyuan
// 
// Revision History
//---------------------------------------------------------------------------------------
// Date         Version    Author      Description
//---------------------------------------------------------------------------------------
//14/02/2013      1.0       PolyU     FIR filter module declaration
//=======================================================================================
#ifndef FIR_H_
#define FIR_H_


#include "define.h"


SC_MODULE (fir) {


public:

   // Inputs
   sc_in_clk clk;
   sc_in<bool> rst;


   //inputs
  sc_in <sc_uint <8> > UUT_in;
  sc_in <bool > input_valid_signal;
  sc_in <bool > output_control_signal;
  //outputs
  sc_out<sc_uint<8> > UUT_out;
  sc_out  <bool > output_valid_signal;



   /* F */
   void fir_main ( void );
   sc_uint<8> filter(sc_uint<8> *, sc_uint<16> *);


   // Constructor
 SC_CTOR (fir) {

       SC_CTHREAD (fir_main, clk.pos() );
       reset_signal_is(rst, false) ;
       sensitive << clk.pos();

   }

   // Destructor
   ~fir() {}


};


#endif   //  FIR_H_

