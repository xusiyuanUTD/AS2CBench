/*
*This software program and documentation are copyrighted by The Hong Kong Polytechnic University. 
*The software program and documentation are supplied ��as *is��, without any accompanying services 
*from The University. The University does not warrant that the operation of the program will be 
*uninterrupted or error-free.The end-user understands that the program was developed for research 
*purposes and is advised not to rely exclusively on the program for any reason.
*
*IN NO EVENT SHALL THE HONG KONG POLYTECHNIC UNIVERSITY BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT, SPECIAL, 
*INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS 
*DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN AD- VISED OF THE POSSIBILITY OF SUCH DAMAGE. THE HONG 
*KONG POLYTECHNIC UNIVERSITY SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
*WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED HEREUNDER IS ON AN ��AS IS�� 
*BASIS, AND THE HONG KONG POLYTECHNIC UNIVERSITY HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, 
*ENHANCEMENTS, OR MODIFICATIONS.
*/
//---------------------------------------------------------------------------
//
//
// File Name    : snow.h
// Description  : stream cipher that forms theheart of the 3GPP confidentiality
//                algorithm UEA2 and the 3GPP integrity algorithm UIA2
//
// Release Date : 26/07/13
// Author       : ETSI/SAGE (www.gsm.com)
// Modified     : PolyU DARC Lab, Xu Siyuan
//
// Revision History
//---------------------------------------------------------------------------
// Date      Version   Author          Description
//---------------------------------------------------------------------------
// 2006        1.0    ETSI/SAGE        Original ANSI C description
//26/07/13     1.1    PolyU DARC Lab   Converted into Synthesizable SystemC
//---------------------------------------------------------------------------


#ifndef SNOW_3G_H
#define SNOW_3G_H

#include "define.h"


typedef sc_uint<8> u8;
typedef sc_uint<32> u32;
typedef sc_biguint<64> u64;


SC_MODULE (snow_3G) {
 
 // inputs
  sc_in_clk        clk;
  sc_in<bool>          rst;

 // sc_in<sc_uint<32> >  ks_in[SIZE];

  // outputs
//  sc_out<sc_uint<32> >  ks_out[SIZE];
   //inputs
  sc_in <sc_uint <32> > UUT_in;
  sc_in <bool > input_valid_signal;
  sc_in <bool > output_control_signal;
  //outputs
  sc_out<sc_uint<32> > UUT_out;
  sc_out  <bool > output_valid_signal;


  /* Variables declaration*/
  sc_uint<32> ks[SIZE];

  /* LFSR */
  u32 LFSR_S0 ;
  u32 LFSR_S1 ;
  u32 LFSR_S2 ;
  u32 LFSR_S3 ;
  u32 LFSR_S4 ;
  u32 LFSR_S5 ;
  u32 LFSR_S6 ;
  u32 LFSR_S7 ;
  u32 LFSR_S8 ;
  u32 LFSR_S9 ;
  u32 LFSR_S10 ;
  u32 LFSR_S11 ;
  u32 LFSR_S12 ;
  u32 LFSR_S13 ;
  u32 LFSR_S14 ;
  u32 LFSR_S15 ;
  /* FSM */
  u32 FSM_R1 ;
  u32 FSM_R2 ;
  u32 FSM_R3 ; 


  /* C */
  sc_uint<32> ClockFSM();
  void ClockLFSRInitializationMode(sc_uint<32>);
  void ClockLFSRKeyStreamMode();


  /* D */
  sc_uint<32> DIValpha(sc_uint<8>);

  /* G */
  void GenerateKeystream();
  
  /* I */
  void Initialize(sc_uint<32> *k, sc_uint<32> *);

  /* M */
  sc_uint<8> MULx(sc_uint<8>, sc_uint<8>);

  template <class T>
  sc_uint<8> MULxPOW(sc_uint<8> , T, sc_uint<8>);
  sc_uint<32>  MULalpha(sc_uint<8>);



  /* S */
  sc_uint<32> S1(sc_uint<32>);
  sc_uint<32> S2(sc_uint<32>);



  SC_CTOR (snow_3G){
     SC_CTHREAD(GenerateKeystream,clk.pos());
     reset_signal_is(rst,false);
  };


  ~snow_3G(){};


};

#endif  // SNOW_3G_H
