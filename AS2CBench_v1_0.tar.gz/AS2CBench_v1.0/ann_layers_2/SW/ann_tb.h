/*
*This software program and documentation are copyrighted by The Hong Kong Polytechnic University. 
*The software program and documentation are supplied ��as *is��, without any accompanying services 
*from The University. The University does not warrant that the operation of the program will be 
*uninterrupted or error-free.The end-user understands that the program was developed for research 
*purposes and is advised not to rely exclusively on the program for any reason.
*
*IN NO EVENT SHALL THE HONG KONG POLYTECHNIC UNIVERSITY BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT, SPECIAL, 
*INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS 
*DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN AD- VISED OF THE POSSIBILITY OF SUCH DAMAGE. THE HONG 
*KONG POLYTECHNIC UNIVERSITY SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
*WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED HEREUNDER IS ON AN ��AS IS�� 
*BASIS, AND THE HONG KONG POLYTECHNIC UNIVERSITY HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, 
*ENHANCEMENTS, OR MODIFICATIONS.
*/
//========================================================================================
// 
// File Name    : ann_tb.h
// Description  : 
// Release Date : 22/10/2014
// 
//
// Revision History
//---------------------------------------------------------------------------------------
// Date         Version         Author          Description
//----------------------------------------------------------------------------------------
// 2014          1.0            David Aledo    ANN testbench header
// 2014          1.1            B Carrion Schafer  added 2 and 4 layer configuration
//=====================================================================================


#ifndef ANN_TB_H
#define ANN_TB_H

#include <stdio.h>
#include <stdlib.h> //rand
#include <time.h>

//#include "tb_confg.h" // Configuration will be done trough sc_main args
#include "synth_param.h" // synthesizable parameters
#include "config.h"
#include "train_parameters.h"
#include "image_parameters.h"
#include "layer.h"


#include <sys/types.h>
#include <math.h>

extern int *a[Nlayer-1]; //global variable for training


   /* Variables */
   FILE *image_in, *im_out;
   unsigned char *image, *result;
   char *bmp_file_in, *bmp_file_out;
   char *bmp_file_in_check, *bmp_file_out_check;

   BITMAPINFOHEADER bitmapInfoHeader;
   BITMAPFILEHEADER bitmapFileHeader; 
   unsigned char biColourPalette[1024];

   int N_tr_block;

   struct layer nn[2];


 //  nn[0] = & nn[0];
  // nn[1] =  & nn[1];

   /* Functions */

   /* D */
   double derived_saturated(int);

   /* E */
   double error_calculation(int *, double *);

   /* I */
   void image_write(char *);

   /* L */
   unsigned char *load_bitmapfile(const char *im_path);
   void learning_cthread(); 
   void initialize();

   /* Constructors */
  // SC_HAS_PROCESS(ann_tb);
  // ann_tb(sc_module_name nm);

   /* Destructor */
 //  ~ann_tb();


#endif
