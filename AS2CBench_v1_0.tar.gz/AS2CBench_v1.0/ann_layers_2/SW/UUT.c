/*
*This software program and documentation are copyrighted by The Hong Kong Polytechnic University. 
*The software program and documentation are supplied ��as *is��, without any accompanying services 
*from The University. The University does not warrant that the operation of the program will be 
*uninterrupted or error-free.The end-user understands that the program was developed for research 
*purposes and is advised not to rely exclusively on the program for any reason.
*
*IN NO EVENT SHALL THE HONG KONG POLYTECHNIC UNIVERSITY BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT, SPECIAL, 
*INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS 
*DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN AD- VISED OF THE POSSIBILITY OF SUCH DAMAGE. THE HONG 
*KONG POLYTECHNIC UNIVERSITY SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
*WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED HEREUNDER IS ON AN ��AS IS�� 
*BASIS, AND THE HONG KONG POLYTECHNIC UNIVERSITY HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, 
*ENHANCEMENTS, OR MODIFICATIONS.
*/
//========================================================================================
// 
// File Name    : test_bench
// Author       : PolyU DARC Lab
//                Benjamin Carrion Schafer, Xu Siyuan
// 
//
//=======================================================================================


#include <stdio.h>
#include <unistd.h>
#include "hwlib.h"
#include "socal/socal.h"
#include "socal/hps.h"
#include "socal/alt_gpio.h"
#include <malloc.h>
#include "stdlib.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <sys/mman.h>
#include "hps_0.h"
#include <stdbool.h>
#include "ann_tb.h"
#include <math.h>

#define HW_REGS_BASE ( ALT_STM_OFST )
#define HW_REGS_SPAN ( 0x04000000 )
#define HW_REGS_MASK ( HW_REGS_SPAN - 1 )

 volatile unsigned long *h2p_lw_UUT_addr;
 volatile unsigned long *h2p_lw_outvalid_addr;
 volatile unsigned long *h2p_lw_wdata_addr;




void initialize(void)
{ int i,n,n_in,n_n;


 for(i=0; i<Nlayer; i++)
{
      n_in=NumN[i];
      n_n=NumN[i+1];
      nn[i].NumIn = n_in;
      nn[i].NumN = n_n;
    //  printf( "NumIn: %d \n ",  nn[i].NumIn );
   //   printf( "NumN: %d \n ",  nn[i].NumN );

      nn[i].b = (signed int*)malloc(nn[i].NumN*nn[i].NumN);
      nn[i].Db = ( float*)malloc(nn[i].NumN*nn[i].NumN);
      nn[i].bprev = (signed int*)malloc(nn[i].NumN*nn[i].NumN);
      nn[i].a = (signed int*)malloc(nn[i].NumN*nn[i].NumN);
      nn[i].s =( float*)malloc(nn[i].NumN*nn[i].NumN);
      nn[i].W = (signed int**)malloc(nn[i].NumN*nn[i].NumN);
      nn[i].DW = ( float**)malloc(nn[i].NumN*nn[i].NumN);
      nn[i].Wprev = (signed int**)malloc(nn[i].NumN*nn[i].NumN);
      for(n=0; n<nn[i].NumN; n++)
      {
         nn[i].W[n] = (signed int*)malloc(nn[i].NumIn*nn[i].NumIn);
         nn[i].DW[n] = ( float*)malloc(nn[i].NumIn*nn[i].NumIn);
         nn[i].Wprev[n] = (signed int*)malloc(nn[i].NumIn*nn[i].NumIn);
      }

}
}


/*
 ** ERROR calculation
 */
double  error_calculation(int *P, double *e)
{
   double MSE = 0.0; // Mean Squared Error
   double aux;
   int i,  Local_e;

   for(i = 0; i < nn[Nlayer-1].NumN; i++)
   {
      Local_e = (P[i] - nn[Nlayer-1].a[i]); // differences between image and trained set
      aux = Local_e * Local_e;
      MSE += aux;
      e[i] = Local_e;
   }
   return MSE;
}




/*
 ** ANN learner main function
 */
void learning_cthread()
{	
   /* Variables */
   int i,j,n,l,i_main;
 signed int outputs[16];
 signed int read,read1;
  // int *P ;//= int[ nn[0].NumIn];  // Input patch. It is also equal to the desired output patch
 int *P = (int*)malloc(nn[0].NumIn*nn[0].NumIn);

  // double *e ;//= double[nn[Nlayer-1].NumN]; // Error between output and desired output
double *e  = (double*)malloc(nn[Nlayer-1].NumN*nn[Nlayer-1].NumIn);
	

   bool worse;
   FILE *ptr_file_results = NULL;

   time_t end,  start=time(NULL);
   double elapsed;

   ptr_file_results = fopen("ann.txt", "wt");
   if(ptr_file_results == NULL)
   {
     printf ( " Cannot create log file ann.txt \n " );
   }

   double Lr;

   int ContAp;
   int ContIt;


   double TMSE; // Total Mean Squared Error
   double TMSE_Min; // Minimal TMSE achieved
   double PSNR; // Peak signal to noise ratio

   /* Reset initialization */
   //wr->write(false);
  // alt_write_word(h2p_lw_UUT_addr,in_filter_read);
   worse = false;
   Lr = Lr_START;
   TMSE_Min = 2e82; //Initialized to a big number
   ContAp = 0;
   ContIt = 0;

 //  printf ( " strating weighting \n " );
  // image = load_bitmapfile(bmp_file_in); // Open the input image file and store it in image array
image = load_bitmapfile(IMAGE_IN); // Open the input image file and store it in image array


   int H = bitmapInfoHeader.biWidth;
   int V = bitmapInfoHeader.biHeight;
   N_tr_block = (H/baseB)*(V/baseB); 


   //wait();

   /* 
    ** Weight and bias RANDOM initialization
    */
  // wr->write(true);
   srand (time(NULL)); // initialize random seed
   for( l=0; l<Nlayer; l++)
   {
      /* Generate RANDOM weights first */
      for( n=0; n<nn[l].NumN; n++)
      {
         for( i=0; i<nn[l].NumIn; i++)
         {
            nn[l].W[n][i] = (rand()%RAND_RANGE) - RAND_RANGE/2;
            //wdata->write(nn[l].W[n][i]);
	alt_write_word(h2p_lw_wdata_addr,nn[l].W[n][i]);
	//printf(" W[%d][%d]is %d \n ",n,i,nn[l].W[n][i]);
	//read1=alt_read_word(h2p_lw_wdata_addr);
	// if (read1 >= 1<<(15)) //Clipping
	//read1=read1-(1<<16);
	//printf(" Received W[%d][%d]is %d \n ",n,i,read1);
	//usleep(100*100);
           // wait();
         }
      }


      /* Generate RANDOM biases second */
      for( n=0; n<nn[l].NumN; n++)
      {
         nn[l].b[n] = (rand()%RAND_RANGE) - RAND_RANGE/2;
        // wdata->write(nn[l].b[n]);
	alt_write_word(h2p_lw_wdata_addr,nn[l].b[n]);
	//printf(" b[%d]is %d \n ",n,nn[l].b[n]);
	//read1=(signed int)alt_read_word(h2p_lw_wdata_addr);
	//if (read1 >= 1<<(15)) //Clipping
	//read1=read1-(1<<16);
	//printf(" b[%d]is %d \n ",n,read1);
	//usleep(100*100);
      //   wait();
      }
   }
  // wr->write(false);

 //  wait();

   /*******************
    **
    ** Main loop
    **
    *******************/

//alt_write_word(h2p_lw_run_in_addr,true);

   do
   {
      TMSE = 0;

      // <-----Start ANN computation for each training image block 
      for ( i_main = 0; i_main < N_tr_block; i_main++)
      {
	//run_in->write(true); 
	
         // Send P to the ANN
         // Next image block
         for ( i=0; i<baseB; i++)
         {
            for ( j=0; j<baseB; j++)
            {
               P[baseB*i+j] = image[(i+(i_main/(H/baseB))*baseB)*H + j+(i_main%(H/baseB))*baseB]-128;
	          // inputs[baseB*i+j]->write(P[baseB*i+j]);
		alt_write_word(h2p_lw_UUT_addr,P[baseB*i+j]);
		//printf(" inputs is %d \n ",P[baseB*i+j]);
		//usleep(100*100);
		//read1=(signed int)alt_read_word(h2p_lw_inputs_addr);
		//	 if (read1 >= 1<<(7)) //Clipping
		//read1=read1-(1<<8);
		//printf(" received inputs is %d \n ",read1);
            }
         }
         
        // wait();
        // run_in->write(false);
	//alt_write_word(h2p_lw_run_in_addr,false);
	
       //  while(!run_out->read()) wait(); // Waiting for the ANN answer
	//while(!(alt_read_word(h2p_lw_run_out_addr))) ;
         /*
          ** FEEDFORWARDS
          */
         for( l=0; l<(Nlayer-1); l++)
         {
            for( i=0; i<nn[l].NumN; i++)
            {
               nn[l].a[i] =0;
            }
         }

	while(1)	{
  	 		 read=alt_read_word(h2p_lw_outvalid_addr);
		//printf(" valid is %d \n ", read);
			if(read)
			{
				for(i=0;i<16;i++){
		alt_write_word(h2p_lw_outvalid_addr,true);	
		outputs[i] =alt_read_word(h2p_lw_UUT_addr);
 		if (outputs[i] >= 1<<(7)) //Clipping
			outputs[i]=outputs[i]-(1<<8);
		}
		break;
		}
	}

         for( i=0; i<nn[Nlayer-1].NumN; i++)
         {
            nn[Nlayer-1].a[i] = outputs[i];
	//printf(" inputs is %d \n ",P[i]);
	 //printf("a %d is %d \n ",i,nn[Nlayer-1].a[i]);
         }
       //  wait();

//printf(" start error calculation \n " );

         /*
          ** ERROR CALCULATION
          */
         TMSE += error_calculation(P, e);



//printf(" start BACKPROPAGATION  \n " );
         /*
          **BACKPROPAGATION
          */
         // Calculation of DW and Db of the output layer



         for( i = 0; i < nn[Nlayer-1].NumN; i++)
         {
            // Calculation of sensibility S of the output layer
            double Local_S2 = -2.0;
	//printf("Local_S2 is %lf  \n ",  Local_S2);
	//printf("e  %d is %lf  \n ", i,e[i]);
            Local_S2 *= e[i];
	//printf("Local_S2 is %lf  \n ",  Local_S2);
            nn[Nlayer-1].s[i] =  Local_S2;
            Local_S2 = Local_S2*Lr;
            nn[Nlayer-1].Db[i] += Local_S2;
	//printf("Local_S2 is %lf  \n ",  Local_S2);


	//printf("after Local_S2 is %lf  \n ",  Local_S2);
            for( j = 0; j < nn[Nlayer-1].NumIn; j++)
            {
	//printf("before , a ,%d = %d, Local_S2 is %f DW %d, %d= %f \n ", j,nn[Nlayer-1].a[j],Local_S2,i,j,nn[Nlayer-1].DW[i][j] );

               nn[Nlayer-1].DW[i][j] += Local_S2 * nn[Nlayer-1].a[j];
	//printf(" a ,%d = %d, Local_S2 is %lf DW %d, %d= %lf \n ", j,nn[Nlayer-1].a[j],Local_S2,i,j,nn[Nlayer-1].DW[i][j] );

            }
         }

//printf(" start  Calculation of DW and Db of the rest layers \n " );

         // Calculation of DW and Db of the rest layers
         for( l=(Nlayer-2); l>=0; l--)
         {
            for( i = 0; i < nn[l].NumN; i++)
            {
               // Calculation of sensibility S
               double Local_S1 = 0.0;
               // S1 = F1*W2'*S2;
               for ( j = 0; j < nn[l+1].NumN; j++)
               {
                  Local_S1 += nn[l+1].W[j][i]*nn[l+1].s[j]*0.000244140625; //*1/(2^12)
               };

               Local_S1 *= derived_saturated(nn[l].a[i]);
	     
               nn[l].s[i] = Local_S1;
               Local_S1 = Local_S1*Lr;
               nn[l].Db[i] += Local_S1;

               // DW1 = Lr*S1*P';
               // As S2 = S2*Lr => DW1 = S1*P
               for(j = 0; j < nn[l].NumIn; j++)
               {
                  if(l==0)
                     nn[l].DW[i][j] += Local_S1*((double)P[j]);
                  else
                     nn[l].DW[i][j] += Local_S1*((double)nn[l-1].a[j]);
               };
            }; // End of calculation of DW and Db
         }
      }
    //  printf(" Finished ANN computation \n " );

      // ----->Finished ANN computation

      // <-----Start calculating the QoR (ERROR)    
      TMSE = TMSE/(H*V);

      if (TMSE > TMSE_Min*Nu_ERROR)
      {
         // It is not converging
         worse = true;
         Lr    = Lr*Ro_DECREASE;
      }
      else if (TMSE <= TMSE_Min) //PF 13+0
      {
         // It is converging
         Lr = Lr*Ephsylon_INCREASE;
         TMSE_Min   = TMSE;
      };
   
      // -----> Finished calculating the QoR (ERROR)  

      /*
       ** Achieved better or worse results as before
       **
       ** If better ==> updating of weights, online
       */
      if(!worse) // Results were better -> Update
      {
         int clipp;
         for( l=0; l<Nlayer; l++)
         {
            for( i=0; i<nn[l].NumN; i++)
            {
               nn[l].bprev[i] = nn[l].b[i];
               clipp = nn[l].b[i] - ((int)(nn[l].Db[i]*4.0));
               if (clipp >= 1<<(NbitW-1)) //Clipping
                  nn[l].b[i] = (1<<(NbitW-1))-1; //0x00007FFF for 16 bits;
               else if (clipp <= -1<<(NbitW-1))
                  nn[l].b[i] = -1<<(NbitW-1); //0xFFFF8000 for 16 bits;
               else
                  nn[l].b[i] = clipp;
               for(j=0; j<nn[l].NumIn; j++)
               {
                  nn[l].Wprev[i][j] = nn[l].W[i][j];
                  clipp = nn[l].W[i][j] - ((int)(nn[l].DW[i][j]*4.0));
                  if (clipp >= 1<<(NbitW-1)) //Clipping
                     nn[l].W[i][j] = (1<<(NbitW-1))-1; //0x00007FFF for 16 bits;
                  else if (clipp <= -1<<(NbitW-1))
                    { nn[l].W[i][j] = -1<<(NbitW-1); //0xFFFF8000 for 16 bits;
			//printf("W[i][j] is %d \n ",nn[l].W[i][j]);
		 }
                  else
                     nn[l].W[i][j] = clipp;
                  nn[l].DW[i][j] = 0.0;
               }
               nn[l].Db[i] = 0.0;
            }
         }
         ContAp++; // no worse iteration
	//printf(" contap is %d \n ",ContAp );
      }
      /*
       ** If worse => restore previous values
       */
      else
      {
         for( l=0; l<Nlayer; l++)
         {
            for( i=0; i<nn[l].NumN; i++)
            {
               nn[l].b[i] = nn[l].bprev[i];
               for(j=0; j<nn[l].NumIn; j++)
               {
                  nn[l].W[i][j] = nn[l].Wprev[i][j];
                  nn[l].DW[i][j] = 0.0;
               }
               nn[l].Db[i] = 0.0;
            }
         }
         worse = false;
      }

      /* Write weights and biases */
   //   wr->write(true);
      for( l=0; l<Nlayer; l++)
      {
         /* Write weights first */
         for(n=0; n<nn[l].NumN; n++)
         {
            for(i=0; i<nn[l].NumIn; i++)
            {
             //  wdata->write(nn[l].W[n][i]);
	alt_write_word(h2p_lw_wdata_addr,nn[l].W[n][i]);


              // wait();
            }
         }
         /* Write biases second */
         for( n=0; n<nn[l].NumN; n++)
         {
          //  wdata->write(nn[l].b[n]);
	alt_write_word(h2p_lw_wdata_addr,nn[l].b[n]);
	          //  wait();
         }
      }

    //  wr->write(false);
 //     wait();

      ContIt++;
	//printf(" TMSE is %lf \n ",TMSE );
    // Exit condition. 
   }while(TMSE > GOAL_ERROR && ContAp < N_ITER);

   end = time(NULL);
   elapsed = difftime(end, start);

  //PSNR = 10*log10( (255*255) / TMSE ); 	//Peak Signal to Noise Ratio (PSNR)

 	printf (  " TMSE: %f \n " ,TMSE );
 //	printf ("PSNR: %f \n ", PSNR);
 	printf ("N_ITER: %d \n ", ContAp );
	printf(" TRAIN_TIME: %0.2lf \n ", elapsed);


   fprintf(ptr_file_results,"TMSE: %0.4lf", TMSE);
 //  fprintf(ptr_file_results,"\nPSNR: %0.4lf", PSNR);
   fprintf(ptr_file_results,"\nN_ITER: %d", N_ITER);
   fprintf(ptr_file_results,"\nTRAIN_TIME: %0.2lf", elapsed);
   fprintf(ptr_file_results,"\nBMP: %s", IMAGE_IN); 


   /***************
    **
    ** Run the ANN a last time to store the final result image
    **
    ***********/

   result = (unsigned char*)malloc(bitmapInfoHeader.biSizeImage);
   for ( i_main = 0; i_main < N_tr_block; i_main++)
   {	
//alt_write_word(h2p_lw_run_in_addr,true);

      for ( i=0; i<baseB; i++)
      {
         for (j=0; j<baseB; j++)
         {
            P[baseB*i+j] = image[(i+(i_main/(H/baseB))*baseB)*H + j+(i_main%(H/baseB))*baseB]-128;
            //inputs[baseB*i+j]->write(P[baseB*i+j]);
		alt_write_word(h2p_lw_UUT_addr,P[baseB*i+j]);
		//printf(" inputs is %d \n ",P[baseB*i+j] );

         }
      }
     // run_in->write(true);
    //  wait();
     // run_in->write(false); 
	//alt_write_word(h2p_lw_run_in_addr,false);
	while(1)	{
  	 		 read=alt_read_word(h2p_lw_outvalid_addr);
		//printf(" valid is %d \n ", read);
			if(read)
			{
				for(i=0;i<16;i++){
		alt_write_word(h2p_lw_outvalid_addr,true);	
		outputs[i] =alt_read_word(h2p_lw_UUT_addr);
		 if (outputs[i] >= 1<<(7)) //Clipping
			outputs[i]=outputs[i]-(1<<8);
		}
		break;
		}
		}
    //  while(!(alt_read_word(h2p_lw_run_out_addr)));

      for ( i=0; i<baseB; i++)
      {
         for (j=0; j<baseB; j++)
         {


            result[(i+(i_main/(H/baseB))*baseB)*H + j+(i_main%(H/baseB))*baseB] = outputs[baseB*i+j]+128;
         }
      }
     // wait();

   }

   /* Store the final result image in BMP file */
   image_write(IMAGE_OUT);
//printf(" Finished image_out \n " );

   /************************************
    **
    ** Verification of test results
    **
    *************************************/
  // delete [] image; // Free memory from the training image
   image = load_bitmapfile(IMAGE_IN_CHECK);

   H = bitmapInfoHeader.biWidth;
   V = bitmapInfoHeader.biHeight;
   N_tr_block = (H/baseB)*(V/baseB);
   TMSE = 0.0;
 //  delete [] result; // Free memory from the training result
  // result = unsigned char[bitmapInfoHeader.biSizeImage];
   for ( i_main = 0; i_main < N_tr_block; i_main++)
   {
	//alt_write_word(h2p_lw_run_in_addr,true);
      for ( i=0; i<baseB; i++)
      {
         for (j=0; j<baseB; j++)
         {
            P[baseB*i+j] = image[(i+(i_main/(H/baseB))*baseB)*H + j+(i_main%(H/baseB))*baseB]-128;
          //  inputs[baseB*i+j]->write(P[baseB*i+j]);
		alt_write_word(h2p_lw_UUT_addr,P[baseB*i+j]);

         }
      }
     // run_in->write(true); 
    //  wait();
     // run_in->write(false);
//alt_write_word(h2p_lw_run_in_addr,false);

    //  while(!run_out->read()) wait();
 //while(!(alt_read_word(h2p_lw_run_out_addr)));
while(1)	{
  	 		 read=alt_read_word(h2p_lw_outvalid_addr);
		//printf(" valid is %d \n ", read);
			if(read)
			{
				for(i=0;i<16;i++){
		alt_write_word(h2p_lw_outvalid_addr,true);	
		outputs[i] =alt_read_word(h2p_lw_UUT_addr);
 		if (outputs[i] >= 1<<(7)) //Clipping
			outputs[i]=outputs[i]-(1<<8);
		}
		break;
		}
		}

      for ( i=0; i<baseB; i++)
      {
         for (j=0; j<baseB; j++)
         {
           nn[Nlayer-1].a[i*baseB+j] = outputs[baseB*i+j];

            result[(i+(i_main/(H/baseB))*baseB)*H + j+(i_main%(H/baseB))*baseB] = nn[Nlayer-1].a[i*baseB+j] + 128;
         }
      }
    //  wait();
      TMSE += error_calculation(P, e);
   }

   TMSE = TMSE/(H*V);
  // PSNR = 10*log10( (255*255) / TMSE ); 	//Peak Signal to Noise Ratio (PSNR)
  printf ( " TMSE_TEST: %f \n " , TMSE );
  //printf (" PSNR_TEST: %f \n " , PSNR );
 

   fprintf(ptr_file_results,"\nTMSE_TEST: %0.4lf", TMSE);
   //fprintf(ptr_file_results,"\nPSNR_TEST: %0.4lf", PSNR);
   fprintf(ptr_file_results,"\nBMP_TEST: %s", IMAGE_IN_CHECK);

   /* Store the final result image in BMP file */
   image_write(IMAGE_OUT_CHECK);

#ifdef PRINTD
   /*  
    ** Record the weights and bias
    */
   fprintf(ptr_file_results,"\n\nWeights&Bias:"); 
   for( l=0; l<Nlayer; l++)
   {
       fprintf(ptr_file_results,"\nLayer %d ",l);
       fprintf(ptr_file_results,"\nWeights:");

       /* Write weights first */
       for( n=0; n<nn[l].NumN; n++)
       {
          fprintf(ptr_file_results,"\n");
          for(i=0; i<nn[l].NumIn; i++)
          {
             fprintf(ptr_file_results,"%d ",nn[l].W[n][i]);
          }
       }
       /* Write biases second */
       fprintf(ptr_file_results,"\nBias:\n");
       for( n=0; n<nn[l].NumN; n++)
       {
	       fprintf(ptr_file_results,"%d ",nn[l].b[n]);
       }
   }
   fprintf(ptr_file_results,"\n\n");
#endif

   fclose(ptr_file_results);

 //  delete [] image;
 //  delete [] result;
 //  delete [] e;
 //  delete [] P;

 printf (  " End of simulation.\n ");
//   exit(1);

}


/******************************
 **
 **  Saturate max values given by NbitOut
 **
 *******************************/
double derived_saturated(int x)
{

  int max= pow(2,NbitOut-1);
  int step = max >> 3;
  if ((x == -(max)) || (x == max-1))
      return 0;
   else if ((x < -(max-step)) || (x > (max-step)))
      return 0.0625;
   else if ((x < -(max-2*step)) || (x > (max-2*step)))
      return 0.125;
   else if ((x < -(max-3*step)) || (x > (max-3*step)))
      return 0.25;
   else if ((x < -(max-4*step)) || (x > (max-4*step)))
      return 0.5;
   else
      return 1;
} 


/******************************
 **
 **  Bitmap loading function
 **
 *******************************/
unsigned char  *load_bitmapfile(const char *im_path)
{
   unsigned char *bitmapImage;


   // Open bmp file to be filtered
   image_in = fopen(im_path,"rb");
   if(!image_in)
   {
    printf (  "Cannot open the file \n " );
      exit(-1);
   }

   fread(&bitmapFileHeader, sizeof(BITMAPFILEHEADER),1,image_in);


   if(bitmapFileHeader.bfType !=0x4D42)
   {
      fclose(image_in);
   }

   // Read the bitmap info header
   fread(&bitmapInfoHeader, sizeof(BITMAPINFOHEADER),1,image_in);

   // Read colour palette
   fread(&biColourPalette,1,bitmapInfoHeader.biClrUsed*4,image_in);


   //move file point to the begging of bitmap data
   fseek(image_in, bitmapFileHeader.bfOffBits, SEEK_SET);

   //allocate enough memory for the bitmap image data
 //  bitmapImage = unsigned char[bitmapInfoHeader.biSizeImage];
 bitmapImage = (unsigned char*)malloc(bitmapInfoHeader.biSizeImage);

   //verify memory allocation
   if(!bitmapImage)
   {
     printf ( "Cannot allocate memory for image \n " );
      return NULL;
   }

   //read in the bitmap image data
   fread(bitmapImage,1, bitmapInfoHeader.biSizeImage,image_in);

   if (bitmapImage == NULL)
   {
     printf ( "Data could not be read \n " );
      return NULL;
   }



    fclose(image_in);
    return bitmapImage;
}


/********************************************
 **
 ** Create new BMP file for filter results 
 **
 *********************************************/
void image_write(char *image_out_name)
{
   // Variables declaration
   int i,j,bytesperline,n;
   int l,k;
   unsigned char *tk;



   k = sizeof(BITMAPFILEHEADER);
   l = sizeof(BITMAPINFOHEADER);

   bytesperline = bitmapInfoHeader.biWidth * BYTES_PER_PIXEL; // multiply by 3 only for 24 bit images

   if( bytesperline & 0x0003)
   {
      bytesperline |= 0x0003;
      ++bytesperline;
   }



   tk = (unsigned char  *)calloc(1,bytesperline);
   bitmapFileHeader.bfSize= bitmapInfoHeader.biSize + (long)bytesperline*bitmapInfoHeader.biHeight;

   bitmapFileHeader.bfOffBits = k+l+ 4*bitmapInfoHeader.biClrUsed;
   bitmapFileHeader.bfSize = k+l+bitmapInfoHeader.biSizeImage;

   n = 0;



   im_out = fopen(image_out_name,"wb");

   if(im_out!=NULL)
   {
      fwrite(&bitmapFileHeader, 1, sizeof(BITMAPFILEHEADER), im_out);
      fwrite(&bitmapInfoHeader, 1, sizeof(BITMAPINFOHEADER), im_out);
      fwrite(biColourPalette, bitmapInfoHeader.biClrUsed*4, 1, im_out);


      for(i=(bitmapInfoHeader.biHeight-1); i>=0; i--)
      {
          for(j=0; j<=(bytesperline)-1; j++)
          {
             tk[j] = result[n++];
          }
          fwrite(tk, 1, bytesperline, im_out);
      }


  }
  else
  {
     printf ( "File not opened \n ");
  }

 fclose(im_out);
 free(tk);

}



//--------------------------
// Main function
//--------------------------


int main(int argc, char **argv)
{


	void *virtual_base;
	int fd;
	//int i;
	double elapsed;
	// map the address space for the LED registers into user space so we can interact with them.
	// we'll actually map in the entire CSR span of the HPS since we want to access various registers within that span
	if( ( fd = open( "/dev/mem", ( O_RDWR | O_SYNC ) ) ) == -1 ) {
		printf( "ERROR: could not open \"/dev/mem\"...\n" );
		return( 1 );
	}
	virtual_base = mmap( NULL, HW_REGS_SPAN, ( PROT_READ | PROT_WRITE ), MAP_SHARED, fd, HW_REGS_BASE );	
	if( virtual_base == MAP_FAILED ) {
		printf( "ERROR: mmap() failed...\n" );
		close( fd );
		return(1);
	}
	h2p_lw_UUT_addr=virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + UUT_IO_BASE) & ( unsigned long)( HW_REGS_MASK ) );
	h2p_lw_outvalid_addr=virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + OUTPUT_VALID_BASE ) & ( unsigned long)( HW_REGS_MASK ) );
	h2p_lw_wdata_addr=virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + WDATA_BASE ) & ( unsigned long)( HW_REGS_MASK ) );
	   
	//printf(" initialize \n ");
	time_t end,start=time(NULL);
	initialize();

	printf(" starting learning \n ");

		learning_cthread();
  	end = time(NULL);
    	elapsed = difftime(end, start);
  	printf("\n\nRunning time %10.4f\n", elapsed);

	if( munmap( virtual_base, HW_REGS_SPAN ) != 0 ) {
		printf( "ERROR: munmap() failed...\n" );
		close( fd );
		return( 1 );

	}
	close( fd );
	return 0;
}
